<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="be_BY">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2469"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2478"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2570"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1995"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1965"/>
        <source>empty passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2489"/>
        <source>gcry_cipher_get_algo_keylen() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2501"/>
        <source>unsupported cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1957"/>
        <source>empty hashType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1973"/>
        <location filename="../Common/spot-on-crypt.cc" line="2453"/>
        <source>empty salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1983"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2668"/>
        <source>generateMcElieceKeys() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2709"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2734"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2764"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2775"/>
        <location filename="../Common/spot-on-crypt.cc" line="2790"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2809"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2865"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3986"/>
        <source>rsaKeySize is less than or equal to zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3993"/>
        <source>rsaKeySize is greater than 4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4001"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4009"/>
        <source>BN_set_word() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4017"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4025"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3914"/>
        <location filename="../Common/spot-on-crypt.cc" line="4033"/>
        <location filename="../Common/spot-on-crypt.cc" line="4041"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4049"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4057"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4631"/>
        <source>newCrypt is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4639"/>
        <source>oldCrypt is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3738"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3935"/>
        <location filename="../Common/spot-on-crypt.cc" line="4070"/>
        <location filename="../Common/spot-on-crypt.cc" line="4088"/>
        <source>calloc() failure or bptr-&gt;length + 1 is irregular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2685"/>
        <source>generateNTRUKeys() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2698"/>
        <source>key type is not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2874"/>
        <source>encryptedThenHashed() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3746"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3755"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3764"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3776"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3784"/>
        <location filename="../Common/spot-on-crypt.cc" line="3795"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3813"/>
        <source>calloc() returned zero or irregular address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3830"/>
        <source>X509_NAME_ENTRY_create_by_NID() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3840"/>
        <source>X509_NAME_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3854"/>
        <source>X509_NAME_add_entry_by_txt() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3862"/>
        <source>X509_NAME_add_entry() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3870"/>
        <source>X509_set_subject_name() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3878"/>
        <source>X509_get_subject_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3886"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3894"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3902"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3922"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="4786"/>
        <source>decryption or encryption failure, or the keys are malformed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="270"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="55"/>
        <source>Re-encoding buzz_channels.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="117"/>
        <source>Re-encoding echo_key_sharing_secrets.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="624"/>
        <source>Re-encoding friends_public_keys.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="893"/>
        <source>Re-encoding kernel_web_server.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="960"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="1381"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="1780"/>
        <source>Re-encoding poptastic.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="1901"/>
        <source>Re-encoding rss.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="2139"/>
        <source>Re-encoding secrets.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="2232"/>
        <source>Re-encoding starbeam.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="2565"/>
        <source>Re-encoding urls_distillers_information.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="2659"/>
        <source>Re-encoding urls_key_information.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1448"/>
        <location filename="../Common/spot-on-misc.cc" line="1451"/>
        <source>0 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1453"/>
        <source>1 Byte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1455"/>
        <source>%1 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1457"/>
        <source>%1 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1460"/>
        <source>%1 MiB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="763"/>
        <source>%1: Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7348"/>
        <location filename="../GUI/spot-on-a.cc" line="7352"/>
        <location filename="../GUI/spot-on-a.cc" line="7355"/>
        <location filename="../GUI/spot-on-a.cc" line="7379"/>
        <location filename="../GUI/spot-on-a.cc" line="7383"/>
        <location filename="../GUI/spot-on-a.cc" line="7386"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9451"/>
        <source>Generating derived keys. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9629"/>
        <location filename="../GUI/spot-on-f.cc" line="1060"/>
        <source>Generating key pairs. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9703"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9727"/>
        <source>An error (%1) occurred with spoton_crypt::keyedHash() or spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10229"/>
        <location filename="../GUI/spot-on-c.cc" line="1150"/>
        <source>&amp;Set Adaptive Echo Token Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10321"/>
        <location filename="../GUI/spot-on-c.cc" line="737"/>
        <source>Chat &amp;Popup...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8730"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8732"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8734"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2295"/>
        <location filename="../GUI/spot-on-c.cc" line="691"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2296"/>
        <location filename="../GUI/spot-on-c.cc" line="710"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="441"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="484"/>
        <source>Percent Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="484"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="589"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="727"/>
        <location filename="../GUI/spot-on-a.cc" line="730"/>
        <location filename="../GUI/spot-on-a.cc" line="733"/>
        <location filename="../GUI/spot-on-a.cc" line="736"/>
        <source>%1 was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="745"/>
        <source>%1: Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3531"/>
        <location filename="../GUI/spot-on-a.cc" line="3539"/>
        <location filename="../GUI/spot-on-a.cc" line="3819"/>
        <location filename="../GUI/spot-on-a.cc" line="3881"/>
        <location filename="../GUI/spot-on-a.cc" line="4234"/>
        <location filename="../GUI/spot-on-a.cc" line="4247"/>
        <location filename="../GUI/spot-on-a.cc" line="4677"/>
        <location filename="../GUI/spot-on-a.cc" line="4683"/>
        <location filename="../GUI/spot-on-a.cc" line="4697"/>
        <location filename="../GUI/spot-on-a.cc" line="5109"/>
        <location filename="../GUI/spot-on-a.cc" line="5115"/>
        <location filename="../GUI/spot-on-a.cc" line="5129"/>
        <location filename="../GUI/spot-on-a.cc" line="5144"/>
        <location filename="../GUI/spot-on-a.cc" line="5440"/>
        <location filename="../GUI/spot-on-a.cc" line="5662"/>
        <location filename="../GUI/spot-on-a.cc" line="9702"/>
        <location filename="../GUI/spot-on-a.cc" line="9711"/>
        <location filename="../GUI/spot-on-a.cc" line="9725"/>
        <location filename="../GUI/spot-on-b.cc" line="621"/>
        <location filename="../GUI/spot-on-b.cc" line="631"/>
        <location filename="../GUI/spot-on-b.cc" line="639"/>
        <location filename="../GUI/spot-on-b.cc" line="679"/>
        <location filename="../GUI/spot-on-b.cc" line="696"/>
        <location filename="../GUI/spot-on-b.cc" line="705"/>
        <location filename="../GUI/spot-on-b.cc" line="715"/>
        <location filename="../GUI/spot-on-b.cc" line="728"/>
        <location filename="../GUI/spot-on-b.cc" line="743"/>
        <location filename="../GUI/spot-on-b.cc" line="822"/>
        <location filename="../GUI/spot-on-b.cc" line="918"/>
        <location filename="../GUI/spot-on-b.cc" line="942"/>
        <location filename="../GUI/spot-on-b.cc" line="951"/>
        <location filename="../GUI/spot-on-b.cc" line="961"/>
        <location filename="../GUI/spot-on-b.cc" line="974"/>
        <location filename="../GUI/spot-on-b.cc" line="1021"/>
        <location filename="../GUI/spot-on-b.cc" line="1040"/>
        <location filename="../GUI/spot-on-b.cc" line="1065"/>
        <location filename="../GUI/spot-on-b.cc" line="1075"/>
        <location filename="../GUI/spot-on-b.cc" line="1088"/>
        <location filename="../GUI/spot-on-b.cc" line="1100"/>
        <location filename="../GUI/spot-on-b.cc" line="1114"/>
        <location filename="../GUI/spot-on-b.cc" line="1185"/>
        <location filename="../GUI/spot-on-b.cc" line="1200"/>
        <location filename="../GUI/spot-on-b.cc" line="1215"/>
        <location filename="../GUI/spot-on-b.cc" line="1264"/>
        <location filename="../GUI/spot-on-b.cc" line="2604"/>
        <location filename="../GUI/spot-on-b.cc" line="2651"/>
        <location filename="../GUI/spot-on-b.cc" line="2674"/>
        <location filename="../GUI/spot-on-b.cc" line="2685"/>
        <location filename="../GUI/spot-on-b.cc" line="2754"/>
        <location filename="../GUI/spot-on-b.cc" line="2859"/>
        <location filename="../GUI/spot-on-b.cc" line="3199"/>
        <location filename="../GUI/spot-on-b.cc" line="3221"/>
        <location filename="../GUI/spot-on-b.cc" line="3252"/>
        <location filename="../GUI/spot-on-b.cc" line="3283"/>
        <location filename="../GUI/spot-on-b.cc" line="3314"/>
        <location filename="../GUI/spot-on-b.cc" line="3345"/>
        <location filename="../GUI/spot-on-b.cc" line="3389"/>
        <location filename="../GUI/spot-on-b.cc" line="3411"/>
        <location filename="../GUI/spot-on-b.cc" line="3431"/>
        <location filename="../GUI/spot-on-b.cc" line="3512"/>
        <location filename="../GUI/spot-on-b.cc" line="3526"/>
        <location filename="../GUI/spot-on-b.cc" line="3548"/>
        <location filename="../GUI/spot-on-b.cc" line="3560"/>
        <location filename="../GUI/spot-on-b.cc" line="3600"/>
        <location filename="../GUI/spot-on-b.cc" line="4130"/>
        <location filename="../GUI/spot-on-b.cc" line="4363"/>
        <location filename="../GUI/spot-on-b.cc" line="4372"/>
        <location filename="../GUI/spot-on-b.cc" line="4380"/>
        <location filename="../GUI/spot-on-b.cc" line="4389"/>
        <location filename="../GUI/spot-on-b.cc" line="5827"/>
        <location filename="../GUI/spot-on-b.cc" line="6057"/>
        <location filename="../GUI/spot-on-b.cc" line="6139"/>
        <location filename="../GUI/spot-on-b.cc" line="6170"/>
        <location filename="../GUI/spot-on-b.cc" line="6182"/>
        <location filename="../GUI/spot-on-b.cc" line="6205"/>
        <location filename="../GUI/spot-on-b.cc" line="6225"/>
        <location filename="../GUI/spot-on-b.cc" line="6239"/>
        <location filename="../GUI/spot-on-b.cc" line="6249"/>
        <location filename="../GUI/spot-on-b.cc" line="6261"/>
        <location filename="../GUI/spot-on-b.cc" line="6307"/>
        <location filename="../GUI/spot-on-c.cc" line="1681"/>
        <location filename="../GUI/spot-on-c.cc" line="1696"/>
        <location filename="../GUI/spot-on-c.cc" line="1709"/>
        <location filename="../GUI/spot-on-c.cc" line="1762"/>
        <location filename="../GUI/spot-on-c.cc" line="2023"/>
        <location filename="../GUI/spot-on-c.cc" line="2362"/>
        <location filename="../GUI/spot-on-c.cc" line="2503"/>
        <location filename="../GUI/spot-on-c.cc" line="2515"/>
        <location filename="../GUI/spot-on-c.cc" line="2555"/>
        <location filename="../GUI/spot-on-c.cc" line="2674"/>
        <location filename="../GUI/spot-on-c.cc" line="2954"/>
        <location filename="../GUI/spot-on-c.cc" line="3940"/>
        <location filename="../GUI/spot-on-c.cc" line="4072"/>
        <location filename="../GUI/spot-on-c.cc" line="4834"/>
        <location filename="../GUI/spot-on-d.cc" line="737"/>
        <location filename="../GUI/spot-on-d.cc" line="794"/>
        <location filename="../GUI/spot-on-d.cc" line="853"/>
        <location filename="../GUI/spot-on-d.cc" line="862"/>
        <location filename="../GUI/spot-on-d.cc" line="939"/>
        <location filename="../GUI/spot-on-d.cc" line="977"/>
        <location filename="../GUI/spot-on-d.cc" line="1092"/>
        <location filename="../GUI/spot-on-d.cc" line="1100"/>
        <location filename="../GUI/spot-on-d.cc" line="1460"/>
        <location filename="../GUI/spot-on-d.cc" line="1472"/>
        <location filename="../GUI/spot-on-d.cc" line="1515"/>
        <location filename="../GUI/spot-on-d.cc" line="1979"/>
        <location filename="../GUI/spot-on-d.cc" line="2093"/>
        <location filename="../GUI/spot-on-d.cc" line="2167"/>
        <location filename="../GUI/spot-on-d.cc" line="2181"/>
        <location filename="../GUI/spot-on-d.cc" line="2197"/>
        <location filename="../GUI/spot-on-d.cc" line="2211"/>
        <location filename="../GUI/spot-on-d.cc" line="2224"/>
        <location filename="../GUI/spot-on-d.cc" line="2310"/>
        <location filename="../GUI/spot-on-d.cc" line="2316"/>
        <location filename="../GUI/spot-on-e.cc" line="791"/>
        <location filename="../GUI/spot-on-e.cc" line="820"/>
        <location filename="../GUI/spot-on-e.cc" line="871"/>
        <location filename="../GUI/spot-on-e.cc" line="1019"/>
        <location filename="../GUI/spot-on-e.cc" line="1096"/>
        <location filename="../GUI/spot-on-e.cc" line="1661"/>
        <location filename="../GUI/spot-on-e.cc" line="1895"/>
        <location filename="../GUI/spot-on-e.cc" line="1946"/>
        <location filename="../GUI/spot-on-f.cc" line="760"/>
        <location filename="../GUI/spot-on-f.cc" line="1147"/>
        <location filename="../GUI/spot-on-f.cc" line="2036"/>
        <location filename="../GUI/spot-on-g.cc" line="111"/>
        <location filename="../GUI/spot-on-g.cc" line="116"/>
        <location filename="../GUI/spot-on-g.cc" line="139"/>
        <location filename="../GUI/spot-on-g.cc" line="150"/>
        <location filename="../GUI/spot-on-g.cc" line="743"/>
        <location filename="../GUI/spot-on-g.cc" line="922"/>
        <location filename="../GUI/spot-on-g.cc" line="1001"/>
        <location filename="../GUI/spot-on-g.cc" line="1030"/>
        <location filename="../GUI/spot-on-g.cc" line="1095"/>
        <location filename="../GUI/spot-on-g.cc" line="1101"/>
        <location filename="../GUI/spot-on-g.cc" line="1568"/>
        <location filename="../GUI/spot-on-g.cc" line="1590"/>
        <location filename="../GUI/spot-on-g.cc" line="1604"/>
        <location filename="../GUI/spot-on-g.cc" line="1617"/>
        <location filename="../GUI/spot-on-g.cc" line="1648"/>
        <location filename="../GUI/spot-on-g.cc" line="1667"/>
        <location filename="../GUI/spot-on-g.cc" line="1759"/>
        <location filename="../GUI/spot-on-g.cc" line="1766"/>
        <location filename="../GUI/spot-on-h.cc" line="867"/>
        <location filename="../GUI/spot-on-h.cc" line="957"/>
        <location filename="../GUI/spot-on-h.cc" line="1441"/>
        <location filename="../GUI/spot-on-h.cc" line="1544"/>
        <location filename="../GUI/spot-on-urls-search.cc" line="561"/>
        <location filename="../GUI/spot-on-urls-search.cc" line="571"/>
        <location filename="../GUI/spot-on-urls.cc" line="398"/>
        <location filename="../GUI/spot-on-urls.cc" line="521"/>
        <location filename="../GUI/spot-on-urls.cc" line="527"/>
        <location filename="../GUI/spot-on-urls.cc" line="541"/>
        <location filename="../GUI/spot-on-urls.cc" line="710"/>
        <location filename="../GUI/spot-on-urls.cc" line="752"/>
        <location filename="../GUI/spot-on-urls.cc" line="837"/>
        <location filename="../GUI/spot-on-urls.cc" line="940"/>
        <location filename="../GUI/spot-on-urls.cc" line="954"/>
        <location filename="../GUI/spot-on-urls.cc" line="1064"/>
        <location filename="../GUI/spot-on-urls.cc" line="1074"/>
        <location filename="../GUI/spot-on-urls.cc" line="1084"/>
        <location filename="../GUI/spot-on-urls.cc" line="1389"/>
        <location filename="../GUI/spot-on-urls.cc" line="1480"/>
        <location filename="../GUI/spot-on-urls.cc" line="1537"/>
        <location filename="../GUI/spot-on-urls.cc" line="1760"/>
        <location filename="../GUI/spot-on-urls.cc" line="1836"/>
        <location filename="../GUI/spot-on-urls.cc" line="1935"/>
        <location filename="../GUI/spot-on-urls.cc" line="1999"/>
        <location filename="../GUI/spot-on-urls.cc" line="2009"/>
        <location filename="../GUI/spot-on-urls.cc" line="2045"/>
        <location filename="../GUI/spot-on-urls.cc" line="2053"/>
        <location filename="../GUI/spot-on-urls.cc" line="2185"/>
        <location filename="../GUI/spot-on-urls.cc" line="2248"/>
        <location filename="../GUI/spot-on-urls.cc" line="2256"/>
        <location filename="../GUI/spot-on-urls.cc" line="2389"/>
        <location filename="../GUI/spot-on-urls.cc" line="2528"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4679"/>
        <source>Unable to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5111"/>
        <source>Unable to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7083"/>
        <location filename="../GUI/spot-on-a.cc" line="7581"/>
        <location filename="../GUI/spot-on-a.cc" line="7817"/>
        <location filename="../GUI/spot-on-a.cc" line="7847"/>
        <location filename="../GUI/spot-on-a.cc" line="8089"/>
        <location filename="../GUI/spot-on-a.cc" line="8225"/>
        <location filename="../GUI/spot-on-a.cc" line="8761"/>
        <location filename="../GUI/spot-on-a.cc" line="8848"/>
        <location filename="../GUI/spot-on-a.cc" line="8942"/>
        <location filename="../GUI/spot-on-b.cc" line="2204"/>
        <location filename="../GUI/spot-on-b.cc" line="2244"/>
        <location filename="../GUI/spot-on-b.cc" line="5600"/>
        <location filename="../GUI/spot-on-b.cc" line="5615"/>
        <location filename="../GUI/spot-on-c.cc" line="3220"/>
        <location filename="../GUI/spot-on-c.cc" line="3233"/>
        <location filename="../GUI/spot-on-c.cc" line="3254"/>
        <location filename="../GUI/spot-on-c.cc" line="3448"/>
        <location filename="../GUI/spot-on-c.cc" line="3762"/>
        <location filename="../GUI/spot-on-c.cc" line="3764"/>
        <location filename="../GUI/spot-on-d.cc" line="444"/>
        <location filename="../GUI/spot-on-d.cc" line="453"/>
        <location filename="../GUI/spot-on-d.cc" line="462"/>
        <location filename="../GUI/spot-on-d.cc" line="602"/>
        <location filename="../GUI/spot-on-d.cc" line="610"/>
        <location filename="../GUI/spot-on-d.cc" line="618"/>
        <location filename="../GUI/spot-on-d.cc" line="626"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="683"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="701"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6260"/>
        <source>External IP: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="141"/>
        <source>The passphrases are not identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="152"/>
        <source>Please provide a name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5684"/>
        <location filename="../GUI/spot-on-a.cc" line="9416"/>
        <location filename="../GUI/spot-on-a.cc" line="9586"/>
        <location filename="../GUI/spot-on-b.cc" line="770"/>
        <location filename="../GUI/spot-on-b.cc" line="798"/>
        <location filename="../GUI/spot-on-b.cc" line="842"/>
        <location filename="../GUI/spot-on-b.cc" line="864"/>
        <location filename="../GUI/spot-on-b.cc" line="3861"/>
        <location filename="../GUI/spot-on-b.cc" line="4204"/>
        <location filename="../GUI/spot-on-b.cc" line="5651"/>
        <location filename="../GUI/spot-on-b.cc" line="5720"/>
        <location filename="../GUI/spot-on-b.cc" line="5916"/>
        <location filename="../GUI/spot-on-b.cc" line="5949"/>
        <location filename="../GUI/spot-on-c.cc" line="2996"/>
        <location filename="../GUI/spot-on-c.cc" line="3053"/>
        <location filename="../GUI/spot-on-c.cc" line="3963"/>
        <location filename="../GUI/spot-on-c.cc" line="3991"/>
        <location filename="../GUI/spot-on-c.cc" line="4095"/>
        <location filename="../GUI/spot-on-e.cc" line="1082"/>
        <location filename="../GUI/spot-on-e.cc" line="1440"/>
        <location filename="../GUI/spot-on-f.cc" line="783"/>
        <location filename="../GUI/spot-on-f.cc" line="1290"/>
        <location filename="../GUI/spot-on-f.cc" line="1315"/>
        <location filename="../GUI/spot-on-g.cc" line="1261"/>
        <location filename="../GUI/spot-on-g.cc" line="1413"/>
        <location filename="../GUI/spot-on-urls.cc" line="570"/>
        <location filename="../GUI/spot-on-urls.cc" line="730"/>
        <location filename="../GUI/spot-on-urls.cc" line="855"/>
        <location filename="../GUI/spot-on-urls.cc" line="1097"/>
        <location filename="../GUI/spot-on-urls.cc" line="1556"/>
        <location filename="../GUI/spot-on-urls.cc" line="1793"/>
        <location filename="../GUI/spot-on-urls.cc" line="2029"/>
        <location filename="../GUI/spot-on-urls.cc" line="2214"/>
        <location filename="../GUI/spot-on-urls.cc" line="2353"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9519"/>
        <source>Re-encoding public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4040"/>
        <location filename="../GUI/spot-on-a.cc" line="9555"/>
        <location filename="../GUI/spot-on-a.cc" line="9807"/>
        <location filename="../GUI/spot-on-a.cc" line="10022"/>
        <location filename="../GUI/spot-on-d.cc" line="156"/>
        <location filename="../GUI/spot-on-d.cc" line="180"/>
        <source>%1: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4050"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9713"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9969"/>
        <source>Initializing URL distillers. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9988"/>
        <source>Importing spot-on-neighbors.txt. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4289"/>
        <location filename="../GUI/spot-on-a.cc" line="4712"/>
        <location filename="../GUI/spot-on-a.cc" line="10002"/>
        <location filename="../GUI/spot-on-b.cc" line="6320"/>
        <location filename="../GUI/spot-on-b.cc" line="7259"/>
        <location filename="../GUI/spot-on-c.cc" line="3091"/>
        <location filename="../GUI/spot-on-f.cc" line="1003"/>
        <location filename="../GUI/spot-on-f.cc" line="1012"/>
        <location filename="../GUI/spot-on-urls.cc" line="138"/>
        <location filename="../GUI/spot-on-urls.cc" line="697"/>
        <location filename="../GUI/spot-on-urls.cc" line="1044"/>
        <location filename="../GUI/spot-on-urls.cc" line="1107"/>
        <location filename="../GUI/spot-on-urls.cc" line="2522"/>
        <source>%1: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3425"/>
        <source>The directory %1 must be readable and writable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4713"/>
        <source>DTLS is not functional over multicast!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8054"/>
        <source>&lt;html&gt;The sticky feature enables an indefinite lifetime for a neighbor. If not checked, the neighbor will be terminated after some internal timer expires. Please note that the neighbor may be terminated if data has not been received for some time.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5681"/>
        <location filename="../GUI/spot-on-b.cc" line="4201"/>
        <source>Are you sure that you wish to deactivate the kernel?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9551"/>
        <source>Would you like to generate public key pairs?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9573"/>
        <location filename="../GUI/spot-on-c.cc" line="3979"/>
        <source>McEliece key pairs require a significant amount of storage memory. As %1 prefers secure memory, the gcrypt library may fail if it&apos;s unable to reserve the required amount of memory. Some operating systems require configuration in order to support large amounts of locked memory. You may disable secure memory by setting the secure memory pools of the interface and the kernel to zero. Continue with the key-generation process?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9804"/>
        <source>Would you like to exercise your new credentials as URL Common Credentials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10139"/>
        <location filename="../GUI/spot-on-a.cc" line="10251"/>
        <location filename="../GUI/spot-on-c.cc" line="1019"/>
        <location filename="../GUI/spot-on-c.cc" line="1172"/>
        <source>Set Socket &amp;Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10165"/>
        <location filename="../GUI/spot-on-c.cc" line="1086"/>
        <source>Share &amp;Open Library Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10186"/>
        <location filename="../GUI/spot-on-c.cc" line="1107"/>
        <source>&amp;Connect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10188"/>
        <location filename="../GUI/spot-on-c.cc" line="1109"/>
        <source>&amp;Disconnect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10195"/>
        <location filename="../GUI/spot-on-c.cc" line="1116"/>
        <source>&amp;Reset Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10199"/>
        <location filename="../GUI/spot-on-c.cc" line="1120"/>
        <source>&amp;Reset Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10211"/>
        <location filename="../GUI/spot-on-c.cc" line="1132"/>
        <source>Delete All Non-Unique &amp;Blocked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10226"/>
        <location filename="../GUI/spot-on-c.cc" line="994"/>
        <location filename="../GUI/spot-on-c.cc" line="1147"/>
        <source>&amp;Copy Adaptive Echo Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10231"/>
        <location filename="../GUI/spot-on-c.cc" line="1152"/>
        <source>&amp;Reset Adaptive Echo Token Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10259"/>
        <location filename="../GUI/spot-on-c.cc" line="1180"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7883"/>
        <location filename="../GUI/spot-on-a.cc" line="7901"/>
        <location filename="../GUI/spot-on-a.cc" line="10262"/>
        <location filename="../GUI/spot-on-c.cc" line="1183"/>
        <source>High Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7889"/>
        <location filename="../GUI/spot-on-a.cc" line="10265"/>
        <location filename="../GUI/spot-on-c.cc" line="1186"/>
        <source>Highest Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7859"/>
        <location filename="../GUI/spot-on-a.cc" line="10268"/>
        <location filename="../GUI/spot-on-c.cc" line="1189"/>
        <source>Idle Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7871"/>
        <location filename="../GUI/spot-on-a.cc" line="10271"/>
        <location filename="../GUI/spot-on-c.cc" line="1192"/>
        <source>Low Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7865"/>
        <location filename="../GUI/spot-on-a.cc" line="10274"/>
        <location filename="../GUI/spot-on-c.cc" line="1195"/>
        <source>Lowest Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7877"/>
        <location filename="../GUI/spot-on-a.cc" line="10277"/>
        <location filename="../GUI/spot-on-c.cc" line="1198"/>
        <source>Normal Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7895"/>
        <location filename="../GUI/spot-on-a.cc" line="10280"/>
        <location filename="../GUI/spot-on-c.cc" line="1201"/>
        <source>Time-Critical Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10375"/>
        <location filename="../GUI/spot-on-c.cc" line="792"/>
        <source>&amp;Generate Random Gemini Pair (Without Call)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10378"/>
        <location filename="../GUI/spot-on-c.cc" line="795"/>
        <source>&amp;Generate Random Gemini Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10461"/>
        <location filename="../GUI/spot-on-a.cc" line="10492"/>
        <location filename="../GUI/spot-on-c.cc" line="1254"/>
        <location filename="../GUI/spot-on-c.cc" line="1291"/>
        <source>&amp;Compute SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10465"/>
        <location filename="../GUI/spot-on-a.cc" line="10495"/>
        <location filename="../GUI/spot-on-c.cc" line="1295"/>
        <source>&amp;Compute SHA3-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10473"/>
        <location filename="../GUI/spot-on-a.cc" line="10503"/>
        <location filename="../GUI/spot-on-c.cc" line="1266"/>
        <location filename="../GUI/spot-on-c.cc" line="1303"/>
        <source>&amp;Copy SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10520"/>
        <location filename="../GUI/spot-on-c.cc" line="1309"/>
        <source>&amp;Duplicate Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6440"/>
        <source>Connected to the kernel on port %1 from local port %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5663"/>
        <source>The e-mail bundle is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5441"/>
        <source>The public keys are too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5146"/>
        <location filename="../GUI/spot-on-d.cc" line="2199"/>
        <source>Invalid neighbor OID. Please select a neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3533"/>
        <source>An error occurred while attempting to record authentication information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3541"/>
        <source>The account name and the account password must contain at least thirty-two characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3874"/>
        <location filename="../GUI/spot-on-b.cc" line="4374"/>
        <location filename="../GUI/spot-on-c.cc" line="1662"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3795"/>
        <source>Invalid clipboard object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10104"/>
        <location filename="../GUI/spot-on-c.cc" line="979"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="469"/>
        <source>%1: Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="475"/>
        <source>%1: Release Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="488"/>
        <source>Statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="488"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="576"/>
        <source>Please note that individual attachments are limited to %1 MiB. Traditional e-mail supports only single attachments. Inline attachments are not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="591"/>
        <source>%1: Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="593"/>
        <source>%1: View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="694"/>
        <source>Please type a message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="696"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="703"/>
        <source>%1: Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="708"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="711"/>
        <location filename="../GUI/spot-on-g.cc" line="319"/>
        <location filename="../GUI/spot-on-g.cc" line="583"/>
        <location filename="../GUI/spot-on-g.cc" line="1550"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="739"/>
        <source>Poptastic is not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="757"/>
        <source>%1: Notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="817"/>
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2299"/>
        <source>Copy &amp;Chat Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2302"/>
        <source>Copy &amp;E-Mail Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2306"/>
        <source>Copy &amp;Open Library Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2311"/>
        <source>Copy &amp;Poptastic Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2314"/>
        <source>Copy &amp;Rosetta Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2317"/>
        <source>Copy &amp;URL Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2320"/>
        <source>Copy &amp;All Public Key Pairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2879"/>
        <source>&lt;html&gt;Please place the Sounds directory in the directory which houses the %1 executable.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3284"/>
        <location filename="../GUI/spot-on-a.cc" line="3288"/>
        <location filename="../GUI/spot-on-a.cc" line="3292"/>
        <location filename="../GUI/spot-on-a.cc" line="3296"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3401"/>
        <source>The SQLite database driver is not available. The file qt.conf is present in %1&apos;s current working directory. Perhaps a conflict exists. Please resolve!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3407"/>
        <source>The SQLite database driver is not available. Please resolve!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4269"/>
        <location filename="../GUI/spot-on-a.cc" line="4306"/>
        <location filename="../GUI/spot-on-g.cc" line="1014"/>
        <location filename="../GUI/spot-on-h.cc" line="1558"/>
        <source>Generating %1-bit SSL/TLS data. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4417"/>
        <source>The specified listener already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4685"/>
        <source>An error (%1) occurred while attempting to add the specified listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4807"/>
        <source>The specified neighbor already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5117"/>
        <source>An error (%1) occurred while attempting to add the specified neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6432"/>
        <source>&lt;html&gt;Connected to the kernel on port %1 from local port %2 via cipher %3.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7105"/>
        <source>&lt;html&gt;Status: %1&lt;br&gt;Bluetooth Flags / SSL Key Size: %2&lt;br&gt;Local IP: %3 Local Port: %4 Scope ID: %5&lt;br&gt;External IP: %6&lt;br&gt;Connections: %7&lt;br&gt;Echo Mode: %8&lt;br&gt;Use Accounts: %9&lt;br&gt;Transport: %10&lt;br&gt;Share Address: %11&lt;br&gt;Orientation: %12&lt;br&gt;SSL Control String: %13&lt;br&gt;Lane Width: %14&lt;br&gt;Passthrough: %15&lt;br&gt;Source of Randomness: %16&lt;br&gt;Socket Options: %17&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7907"/>
        <source>&lt;html&gt;UUID: %1&lt;br&gt;Status: %2&lt;br&gt;SSL Key Size: %3&lt;br&gt;Local IP: %4 Local Port: %5&lt;br&gt;External IP: %6&lt;br&gt;Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10&lt;br&gt;Proxy Hostname: %11 Proxy Port: %12&lt;br&gt;Echo Mode: %13&lt;br&gt;Communications Mode: %14&lt;br&gt;Uptime: %15 Minutes&lt;br&gt;Allow Certificate Exceptions: %16&lt;br&gt;Bytes Read: %17&lt;br&gt;Bytes Written: %18&lt;br&gt;SSL Session Cipher: %19&lt;br&gt;Account Name: %20&lt;br&gt;Account Authenticated: %21&lt;br&gt;Transport: %22&lt;br&gt;Orientation: %23&lt;br&gt;SSL Control String: %24&lt;br&gt;Priority: %25&lt;br&gt;Lane Width: %26&lt;br&gt;Passthrough: %27&lt;br&gt;Wait-For-Bytes-Written: %28&lt;br&gt;Silence Time: %29&lt;br&gt;Socket Options: %30&lt;br&gt;Buffered Content: %31&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8342"/>
        <source>A positive value ([%1, %2]) may pause the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8399"/>
        <source>&lt;html&gt;A value of 0 will prevent the neighbor from terminating itself if data has not been received for some time.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10333"/>
        <location filename="../GUI/spot-on-c.cc" line="749"/>
        <source>MELODICA: &amp;Call Friend (New Gemini Pair)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10340"/>
        <location filename="../GUI/spot-on-c.cc" line="757"/>
        <source>MELODICA: &amp;Call Friend (New Gemini Pair Using Existing Gemini Pair)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10349"/>
        <location filename="../GUI/spot-on-c.cc" line="766"/>
        <source>MELODICA Two-Way: &amp;Call Friend (New Gemini Pair)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10356"/>
        <location filename="../GUI/spot-on-c.cc" line="773"/>
        <source>&amp;Call Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10360"/>
        <location filename="../GUI/spot-on-c.cc" line="776"/>
        <source>&amp;Call Participant (Existing Gemini Pair)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10363"/>
        <location filename="../GUI/spot-on-c.cc" line="780"/>
        <source>&amp;Two-Way Calling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10369"/>
        <location filename="../GUI/spot-on-c.cc" line="786"/>
        <source>&amp;Terminate Call</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10392"/>
        <location filename="../GUI/spot-on-c.cc" line="809"/>
        <source>&amp;Derive Gemini Pair From SMP Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10395"/>
        <location filename="../GUI/spot-on-c.cc" line="812"/>
        <source>&amp;Reset SMP Machine&apos;s Internal State (S0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10398"/>
        <location filename="../GUI/spot-on-c.cc" line="815"/>
        <source>&amp;Set SMP Secret...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10401"/>
        <location filename="../GUI/spot-on-c.cc" line="818"/>
        <source>&amp;Verify SMP Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10405"/>
        <location filename="../GUI/spot-on-c.cc" line="822"/>
        <source>Replay &amp;Last %1 Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10414"/>
        <location filename="../GUI/spot-on-c.cc" line="831"/>
        <source>Share &amp;StarBeam With Selected Participant(s)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10421"/>
        <location filename="../GUI/spot-on-c.cc" line="838"/>
        <source>Call Via Forward &amp;Secrecy Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10440"/>
        <location filename="../GUI/spot-on-c.cc" line="855"/>
        <source>Invite Selected Participant(s) (Anonymous Buzz Channel)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4148"/>
        <source>Launching the kernel. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4235"/>
        <source>The kernel process could not be started. Good luck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4013"/>
        <location filename="../GUI/spot-on-a.cc" line="6255"/>
        <source>&lt;html&gt;&lt;a href=&quot;authenticate&quot;&gt;The kernel requires your authentication and encryption keys.&lt;/a&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2293"/>
        <location filename="../GUI/spot-on-a.cc" line="6464"/>
        <source>&lt;html&gt;The interface is not connected to the kernel. Is the kernel active?&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9339"/>
        <source>%1: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9343"/>
        <location filename="../GUI/spot-on-a.cc" line="9368"/>
        <location filename="../GUI/spot-on-c.cc" line="2971"/>
        <location filename="../GUI/spot-on-c.cc" line="3025"/>
        <location filename="../GUI/spot-on-c.cc" line="4455"/>
        <location filename="../GUI/spot-on-c.cc" line="4476"/>
        <location filename="../GUI/spot-on-d.cc" line="760"/>
        <location filename="../GUI/spot-on-d.cc" line="2005"/>
        <location filename="../GUI/spot-on-e.cc" line="1806"/>
        <location filename="../GUI/spot-on-e.cc" line="2066"/>
        <location filename="../GUI/spot-on-urls.cc" line="1961"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9364"/>
        <source>%1: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9401"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the future Re-Encode URLs option. The RSS mechanism and the kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9407"/>
        <source>Are you sure that you wish to replace the existing answer/question? Please note that URL data must be re-encoded via a separate tool. Please see the future Re-Encode URLs option. The RSS mechanism and the kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="9634"/>
        <location filename="../GUI/spot-on-f.cc" line="1064"/>
        <source>%1: Generating Key Pairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10054"/>
        <location filename="../GUI/spot-on-a.cc" line="10318"/>
        <location filename="../GUI/spot-on-a.cc" line="10533"/>
        <location filename="../GUI/spot-on-c.cc" line="734"/>
        <location filename="../GUI/spot-on-c.cc" line="917"/>
        <location filename="../GUI/spot-on-c.cc" line="1334"/>
        <source>&amp;Add Participant As Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10060"/>
        <location filename="../GUI/spot-on-a.cc" line="10539"/>
        <location filename="../GUI/spot-on-c.cc" line="923"/>
        <location filename="../GUI/spot-on-c.cc" line="1340"/>
        <source>&amp;Copy Keys (Clipboard Buffer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10063"/>
        <location filename="../GUI/spot-on-a.cc" line="10325"/>
        <location filename="../GUI/spot-on-a.cc" line="10542"/>
        <location filename="../GUI/spot-on-c.cc" line="741"/>
        <location filename="../GUI/spot-on-c.cc" line="926"/>
        <location filename="../GUI/spot-on-c.cc" line="1343"/>
        <source>&amp;Copy Repleo (Clipboard Buffer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10069"/>
        <location filename="../GUI/spot-on-a.cc" line="10385"/>
        <location filename="../GUI/spot-on-a.cc" line="10548"/>
        <location filename="../GUI/spot-on-c.cc" line="802"/>
        <location filename="../GUI/spot-on-c.cc" line="932"/>
        <location filename="../GUI/spot-on-c.cc" line="1349"/>
        <source>&amp;Remove Participant(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10072"/>
        <location filename="../GUI/spot-on-a.cc" line="10388"/>
        <location filename="../GUI/spot-on-a.cc" line="10551"/>
        <location filename="../GUI/spot-on-c.cc" line="805"/>
        <location filename="../GUI/spot-on-c.cc" line="935"/>
        <location filename="../GUI/spot-on-c.cc" line="1352"/>
        <source>&amp;Rename Participant...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10077"/>
        <location filename="../GUI/spot-on-a.cc" line="10424"/>
        <location filename="../GUI/spot-on-c.cc" line="840"/>
        <location filename="../GUI/spot-on-c.cc" line="939"/>
        <source>Initiate Forward &amp;Secrecy Exchange(s)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6446"/>
        <source>&lt;html&gt;Connected to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6459"/>
        <source>&lt;html&gt;The interface is not connected to the kernel. However, the kernel appears to be active. Perhaps the kernel&apos;s UI server has been disabled.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3475"/>
        <source>%1: Authenticate Neighbor Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10106"/>
        <location filename="../GUI/spot-on-c.cc" line="981"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4290"/>
        <source>You&apos;re attempting to create a UDP multicast listener. Please create a UDP multicast neighbor instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10081"/>
        <location filename="../GUI/spot-on-a.cc" line="10428"/>
        <location filename="../GUI/spot-on-c.cc" line="843"/>
        <location filename="../GUI/spot-on-c.cc" line="942"/>
        <source>Purge Forward &amp;Secrecy Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10085"/>
        <location filename="../GUI/spot-on-a.cc" line="10432"/>
        <location filename="../GUI/spot-on-c.cc" line="847"/>
        <source>Reset Forward &amp;Secrecy Information of Selected Participant(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10109"/>
        <location filename="../GUI/spot-on-c.cc" line="984"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10111"/>
        <location filename="../GUI/spot-on-c.cc" line="986"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10120"/>
        <location filename="../GUI/spot-on-a.cc" line="10235"/>
        <location filename="../GUI/spot-on-c.cc" line="999"/>
        <location filename="../GUI/spot-on-c.cc" line="1156"/>
        <source>&amp;Copy Private Application Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10124"/>
        <location filename="../GUI/spot-on-a.cc" line="10239"/>
        <location filename="../GUI/spot-on-c.cc" line="1003"/>
        <location filename="../GUI/spot-on-c.cc" line="1160"/>
        <source>&amp;Set Private Application Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10128"/>
        <location filename="../GUI/spot-on-a.cc" line="10243"/>
        <location filename="../GUI/spot-on-c.cc" line="1007"/>
        <location filename="../GUI/spot-on-c.cc" line="1164"/>
        <source>&amp;Reset Private Application Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10135"/>
        <location filename="../GUI/spot-on-a.cc" line="10247"/>
        <location filename="../GUI/spot-on-c.cc" line="1015"/>
        <location filename="../GUI/spot-on-c.cc" line="1168"/>
        <source>Set &amp;SSL Control String...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10154"/>
        <location filename="../GUI/spot-on-c.cc" line="1075"/>
        <source>Share &amp;Chat Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10159"/>
        <location filename="../GUI/spot-on-c.cc" line="1080"/>
        <source>Share &amp;E-Mail Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10171"/>
        <location filename="../GUI/spot-on-c.cc" line="1092"/>
        <source>Share &amp;Poptastic Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10176"/>
        <location filename="../GUI/spot-on-c.cc" line="1097"/>
        <source>Share &amp;URL Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10179"/>
        <location filename="../GUI/spot-on-c.cc" line="1100"/>
        <source>&amp;Assign New Remote IP Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10192"/>
        <location filename="../GUI/spot-on-c.cc" line="1113"/>
        <source>&amp;Authenticate Account...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10213"/>
        <location filename="../GUI/spot-on-c.cc" line="1134"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10216"/>
        <location filename="../GUI/spot-on-c.cc" line="1137"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10218"/>
        <location filename="../GUI/spot-on-c.cc" line="1139"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10114"/>
        <location filename="../GUI/spot-on-a.cc" line="10221"/>
        <location filename="../GUI/spot-on-c.cc" line="989"/>
        <location filename="../GUI/spot-on-c.cc" line="1142"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10116"/>
        <location filename="../GUI/spot-on-a.cc" line="10223"/>
        <location filename="../GUI/spot-on-c.cc" line="991"/>
        <location filename="../GUI/spot-on-c.cc" line="1144"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3834"/>
        <location filename="../GUI/spot-on-a.cc" line="4248"/>
        <location filename="../GUI/spot-on-a.cc" line="4699"/>
        <location filename="../GUI/spot-on-a.cc" line="5131"/>
        <location filename="../GUI/spot-on-b.cc" line="623"/>
        <location filename="../GUI/spot-on-b.cc" line="2653"/>
        <location filename="../GUI/spot-on-b.cc" line="2774"/>
        <location filename="../GUI/spot-on-b.cc" line="3391"/>
        <location filename="../GUI/spot-on-b.cc" line="3528"/>
        <location filename="../GUI/spot-on-b.cc" line="6227"/>
        <location filename="../GUI/spot-on-c.cc" line="1588"/>
        <location filename="../GUI/spot-on-c.cc" line="1698"/>
        <location filename="../GUI/spot-on-c.cc" line="2505"/>
        <location filename="../GUI/spot-on-c.cc" line="2956"/>
        <location filename="../GUI/spot-on-c.cc" line="4614"/>
        <location filename="../GUI/spot-on-d.cc" line="656"/>
        <location filename="../GUI/spot-on-d.cc" line="796"/>
        <location filename="../GUI/spot-on-d.cc" line="979"/>
        <location filename="../GUI/spot-on-d.cc" line="1462"/>
        <location filename="../GUI/spot-on-d.cc" line="1981"/>
        <location filename="../GUI/spot-on-d.cc" line="2183"/>
        <location filename="../GUI/spot-on-e.cc" line="822"/>
        <location filename="../GUI/spot-on-e.cc" line="1098"/>
        <location filename="../GUI/spot-on-e.cc" line="1897"/>
        <location filename="../GUI/spot-on-e.cc" line="2019"/>
        <location filename="../GUI/spot-on-f.cc" line="177"/>
        <location filename="../GUI/spot-on-f.cc" line="1839"/>
        <location filename="../GUI/spot-on-g.cc" line="1002"/>
        <location filename="../GUI/spot-on-g.cc" line="1570"/>
        <location filename="../GUI/spot-on-h.cc" line="868"/>
        <location filename="../GUI/spot-on-h.cc" line="1545"/>
        <location filename="../GUI/spot-on-urls.cc" line="399"/>
        <location filename="../GUI/spot-on-urls.cc" line="1065"/>
        <location filename="../GUI/spot-on-urls.cc" line="1390"/>
        <location filename="../GUI/spot-on-urls.cc" line="1782"/>
        <location filename="../GUI/spot-on-urls.cc" line="1862"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7153"/>
        <location filename="../GUI/spot-on-a.cc" line="7155"/>
        <location filename="../GUI/spot-on-a.cc" line="7164"/>
        <location filename="../GUI/spot-on-a.cc" line="7997"/>
        <location filename="../GUI/spot-on-a.cc" line="8019"/>
        <location filename="../GUI/spot-on-a.cc" line="8037"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="7153"/>
        <location filename="../GUI/spot-on-a.cc" line="7155"/>
        <location filename="../GUI/spot-on-a.cc" line="7164"/>
        <location filename="../GUI/spot-on-a.cc" line="7997"/>
        <location filename="../GUI/spot-on-a.cc" line="8019"/>
        <location filename="../GUI/spot-on-a.cc" line="8037"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10004"/>
        <source>Your confidential information has been saved. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10507"/>
        <location filename="../GUI/spot-on-c.cc" line="1312"/>
        <source>Set &amp;Pulse Size...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10509"/>
        <location filename="../GUI/spot-on-c.cc" line="1314"/>
        <source>Set &amp;Read Interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4032"/>
        <source>The kernel process %1 requires your private authentication and encryption keys. Would you like to share the keys with the kernel process?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8736"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="8817"/>
        <location filename="../GUI/spot-on-a.cc" line="8958"/>
        <location filename="../GUI/spot-on-a.cc" line="9008"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10132"/>
        <location filename="../GUI/spot-on-c.cc" line="1012"/>
        <source>&amp;Prepare New One-Year Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10181"/>
        <location filename="../GUI/spot-on-c.cc" line="1102"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10018"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10183"/>
        <location filename="../GUI/spot-on-c.cc" line="1104"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10099"/>
        <location filename="../GUI/spot-on-a.cc" line="10207"/>
        <location filename="../GUI/spot-on-a.cc" line="10456"/>
        <location filename="../GUI/spot-on-a.cc" line="10487"/>
        <location filename="../GUI/spot-on-c.cc" line="974"/>
        <location filename="../GUI/spot-on-c.cc" line="1046"/>
        <location filename="../GUI/spot-on-c.cc" line="1128"/>
        <location filename="../GUI/spot-on-c.cc" line="1249"/>
        <location filename="../GUI/spot-on-c.cc" line="1286"/>
        <location filename="../GUI/spot-on-c.cc" line="4545"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10101"/>
        <location filename="../GUI/spot-on-a.cc" line="10209"/>
        <location filename="../GUI/spot-on-a.cc" line="10458"/>
        <location filename="../GUI/spot-on-a.cc" line="10489"/>
        <location filename="../GUI/spot-on-c.cc" line="976"/>
        <location filename="../GUI/spot-on-c.cc" line="1048"/>
        <location filename="../GUI/spot-on-c.cc" line="1130"/>
        <location filename="../GUI/spot-on-c.cc" line="1251"/>
        <location filename="../GUI/spot-on-c.cc" line="1288"/>
        <location filename="../GUI/spot-on-c.cc" line="4547"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5001"/>
        <source>&lt;i&gt;%2...%3 cordially invites you to join a Buzz channel. Please &lt;a href=&apos;%1&apos;&gt;accept&lt;/a&gt; the invitation. If accepted, a new window will be displayed.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2447"/>
        <location filename="../GUI/spot-on-b.cc" line="2452"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2491"/>
        <location filename="../GUI/spot-on-b.cc" line="6241"/>
        <location filename="../GUI/spot-on-f.cc" line="967"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2470"/>
        <location filename="../GUI/spot-on-b.cc" line="6052"/>
        <location filename="../GUI/spot-on-e.cc" line="2030"/>
        <location filename="../GUI/spot-on-f.cc" line="956"/>
        <location filename="../GUI/spot-on-f.cc" line="1844"/>
        <location filename="../GUI/spot-on-urls.cc" line="2177"/>
        <source>The interface is not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2476"/>
        <location filename="../GUI/spot-on-b.cc" line="6049"/>
        <location filename="../GUI/spot-on-e.cc" line="2037"/>
        <location filename="../GUI/spot-on-f.cc" line="962"/>
        <location filename="../GUI/spot-on-f.cc" line="1850"/>
        <location filename="../GUI/spot-on-urls.cc" line="2180"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2481"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5083"/>
        <source>&lt;i&gt;Received an%1SMP message from %2 (%3...%4).&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5135"/>
        <source>&lt;i&gt;Unable to respond because an SMP object is not defined for %1 (%2...%3).&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5208"/>
        <source>&lt;font color=green&gt;&lt;i&gt;SMP verification with %1 (%2...%3) has succeeded.&lt;/i&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5219"/>
        <source>&lt;font color=red&gt;&lt;i&gt;SMP verification with %1 (%2...%3) has failed.&lt;/i&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5237"/>
        <source>&lt;font color=red&gt;&lt;i&gt;SMP verification with %1 (%2...%3) has experienced a protocol failure. The respective state machine has been reset.&lt;/i&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5716"/>
        <source>Are you sure that you wish to remove the selected Chat participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="730"/>
        <location filename="../GUI/spot-on-b.cc" line="1102"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="763"/>
        <source>Unable to retrieve your %1 public key for comparison. Are you sure that you wish to accept the foreign key pair?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="792"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Are you sure that you wish to accept the foreign key pair?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="976"/>
        <location filename="../GUI/spot-on-b.cc" line="1042"/>
        <source>Irregular data. Expecting 3 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1090"/>
        <source>Symmetric decryption failure. Serious!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5943"/>
        <source>Are you sure that you wish to reset %1? All data will be lost. PostgreSQL databases must be removed separately.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6172"/>
        <source>The attachment %1 cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6251"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6620"/>
        <source>E-mail has been queued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1996"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1999"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2001"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4382"/>
        <source>The provided Gold Bug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4015"/>
        <source>Please provide a channel key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4027"/>
        <source>Please provide a hash key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1776"/>
        <source>Generating SSL/TLS %1-bit kernel socket credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2756"/>
        <source>Unable to record the IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="7255"/>
        <source>Empty cipher list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="698"/>
        <location filename="../GUI/spot-on-b.cc" line="944"/>
        <location filename="../GUI/spot-on-c.cc" line="3942"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="707"/>
        <location filename="../GUI/spot-on-b.cc" line="953"/>
        <source>Empty key(s). Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="717"/>
        <source>Invalid key(s). The provided text must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="824"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="838"/>
        <source>Invalid %1 public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="860"/>
        <source>Invalid %1 signature public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1067"/>
        <source>Unable to compute a keyed hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1077"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1187"/>
        <source>You&apos;re attempting to add your own keys or %1 was not able to retrieve your keys for comparison.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4945"/>
        <source>Participant &lt;b&gt;%1&lt;/b&gt; (%2) has completed a Forward Secrecy exchange.&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5828"/>
        <source>Cannot reply to an encrypted message. Please decrypt the message by providing the correct Gold Bug.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5912"/>
        <source>Would you like to save the e-mail address %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6207"/>
        <source>An error occurred while reading the attachment %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6263"/>
        <source>Please provide a Gold Bug that contains at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6309"/>
        <source>At least one of the selected e-mail recipients is temporary. Please correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6322"/>
        <source>The Poptastic &amp; RetroPhone Settings window will be displayed. Please prepare at least one Poptastic account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6623"/>
        <source>GoldBug: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="963"/>
        <source>Invalid repleo(s). The provided text must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3222"/>
        <source>The chat public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="633"/>
        <source>Please provide a normal e-mail address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="641"/>
        <source>Empty e-mail address. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="681"/>
        <location filename="../GUI/spot-on-b.cc" line="920"/>
        <location filename="../GUI/spot-on-b.cc" line="1266"/>
        <source>An error occurred while attempting to save the friendship bundle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="745"/>
        <location filename="../GUI/spot-on-b.cc" line="1116"/>
        <source>Invalid key type. Expecting &apos;chat&apos;, &apos;email&apos;, &apos;open-library&apos;, &apos;poptastic&apos;, &apos;rosetta&apos;, or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1023"/>
        <source>Asymmetric decryption failure. Are you attempting to add a repleo that you gathered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1202"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;open-library&apos;, &apos;poptastic&apos;, &apos;rosetta&apos;, or &apos;url&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1217"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;open-library&apos;, &apos;poptastic&apos;, &apos;rosetta&apos;, or &apos;url&apos; signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3200"/>
        <source>The chat bundle is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6141"/>
        <source>The file email.db has exceeded the defined limit. Please remove some entries and/or increase the limit via the Permissions section in Options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="6184"/>
        <source>The attachment %1 is too large. The maximum size of an attachment is %2 byte(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3253"/>
        <source>The e-mail public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1683"/>
        <source>&lt;html&gt;Remote peer %1 is requesting authentication credentials.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2509"/>
        <source>&lt;b&gt;me&lt;/b&gt; (&lt;font color=gray&gt;%1&lt;/font&gt;)&lt;b&gt;:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3284"/>
        <source>The poptastic public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3315"/>
        <source>The rosetta public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3346"/>
        <source>The URL public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4326"/>
        <source>%1: Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4365"/>
        <source>An error occurred while processing the attachment(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4391"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4444"/>
        <source>&lt;font color=#9F6000&gt;&lt;b&gt;The message was not digitally signed or digital signatures are not supported.&lt;/b&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4452"/>
        <source>&lt;font color=#4F8A10&gt;&lt;b&gt;The message appears to have been digitally signed.&lt;/b&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4458"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4461"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4463"/>
        <location filename="../GUI/spot-on-b.cc" line="4491"/>
        <location filename="../GUI/spot-on-b.cc" line="4507"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4466"/>
        <location filename="../GUI/spot-on-b.cc" line="4494"/>
        <location filename="../GUI/spot-on-b.cc" line="4510"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4486"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4488"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4501"/>
        <location filename="../GUI/spot-on-b.cc" line="4504"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3858"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5871"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4021"/>
        <source>Please provide a channel salt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5647"/>
        <source>Are you sure that you wish to remove the selected E-Mail participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2675"/>
        <location filename="../GUI/spot-on-b.cc" line="2789"/>
        <location filename="../GUI/spot-on-b.cc" line="3413"/>
        <location filename="../GUI/spot-on-b.cc" line="3550"/>
        <location filename="../GUI/spot-on-d.cc" line="2128"/>
        <source>Invalid listener OID. Please select a listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2687"/>
        <source>Please provide an IP address or the keyword Any.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3433"/>
        <source>Please select an address to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3514"/>
        <source>An error occurred while attempting to delete the specified IP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="7249"/>
        <source>The following ciphers are supported by your OpenSSL library. Please note that %1 may neglect discovered ciphers if the ciphers are not also understood by Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2795"/>
        <source>Please provide an account name that contains at least thirty-two characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2801"/>
        <source>Please provide an account password that contains at least thirty-two characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2853"/>
        <location filename="../GUI/spot-on-d.cc" line="731"/>
        <source>A database error has occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3562"/>
        <source>Please select an account to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3602"/>
        <source>An error occurred while attempting to delete the specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="10518"/>
        <location filename="../GUI/spot-on-c.cc" line="1040"/>
        <location filename="../GUI/spot-on-c.cc" line="1307"/>
        <location filename="../GUI/spot-on-c.cc" line="4539"/>
        <source>Copy &amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4472"/>
        <location filename="../GUI/spot-on-e.cc" line="2062"/>
        <source>%1: Select StarBeam Transmit File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4621"/>
        <source>Please provide a nova that contains at least forty-eight characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4628"/>
        <source>Please select a file to transfer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4636"/>
        <source>The provided file cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3538"/>
        <location filename="../GUI/spot-on-c.cc" line="3845"/>
        <source>%1% - %2 of %3 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3543"/>
        <location filename="../GUI/spot-on-c.cc" line="3850"/>
        <source>%1% - %2 (%3 Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1711"/>
        <source>Please provide a nova that contains at least forty-eight characters. Reach for the stars!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="878"/>
        <source>New E-mail Window...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="896"/>
        <source>Gather Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="946"/>
        <source>Reset Forward &amp;Secrecy Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1258"/>
        <source>&amp;Compute SHA3-512  Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1581"/>
        <source>StarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1600"/>
        <source>Buzz / Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2557"/>
        <source>An error occurred while attempting to delete the speficied nova.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3591"/>
        <source>&lt;html&gt;The computed file digest is identical to the expected file digest.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3599"/>
        <source>&lt;html&gt;The computed file digest does not equal the expected file digest.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3954"/>
        <source>Are you sure that you wish to generate the selected key pair? StarBeam digest computations will be interrupted. The kernel will also be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3958"/>
        <source>Are you sure that you wish to generate the selected key pair? The kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4074"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2024"/>
        <source>The e-mail keys are too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2691"/>
        <location filename="../GUI/spot-on-c.cc" line="2763"/>
        <location filename="../GUI/spot-on-urls.cc" line="2083"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3092"/>
        <source>A total of %1 key pair(s) were imported and %2 key pair(s) were not imported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2685"/>
        <source>%1: Select Listeners Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2965"/>
        <source>%1: Select Neighbors Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2363"/>
        <source>The URL bundle is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4091"/>
        <source>Are you sure that you wish to remove the selected URLs participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4204"/>
        <source>%1: New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4205"/>
        <location filename="../GUI/spot-on-g.cc" line="1199"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4451"/>
        <source>%1: Select StarBeam Destination Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1622"/>
        <source>Invalid StarBeam magnet. Are you missing tokens?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1764"/>
        <source>Unable to store the nova.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2517"/>
        <source>Please select a nova to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="889"/>
        <source>Delete URL Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="892"/>
        <source>Drop URL Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2757"/>
        <source>%1: Select Public Keys Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3019"/>
        <source>%1: Select Public Keys Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2990"/>
        <location filename="../GUI/spot-on-c.cc" line="3047"/>
        <source>The import file %1 contains a lot (%2) of data. Are you sure that you wish to process it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2676"/>
        <source>Unable to export an empty listeners table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4655"/>
        <source>Please select at least one magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4818"/>
        <location filename="../GUI/spot-on-c.cc" line="4820"/>
        <source>A database error (%1) occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="4822"/>
        <source>An error occurred within spoton_crypt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="855"/>
        <source>Please provide an institution name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="864"/>
        <source>Please provide an institution postal address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="941"/>
        <source>Unable to record the institution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2153"/>
        <source>Database error. Unable to save the message of the day.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2156"/>
        <source>Unable to open listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1702"/>
        <source>&amp;Add magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1094"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1102"/>
        <source>An error (%1) occurred while attempting to save the channel data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="666"/>
        <source>Invalid adaptive echo magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="678"/>
        <source>Please provide a token and a token type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="683"/>
        <source>Please provide a token that contains at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1474"/>
        <source>Please select a token to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1517"/>
        <source>An error occurred while attempting to delete the specified adaptive echo token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2213"/>
        <location filename="../GUI/spot-on-f.cc" line="1858"/>
        <location filename="../GUI/spot-on-g.cc" line="1606"/>
        <source>The method spoton_crypt::cipherTypes() has failed. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2226"/>
        <location filename="../GUI/spot-on-f.cc" line="1867"/>
        <location filename="../GUI/spot-on-g.cc" line="1619"/>
        <source>The method spoton_crypt::hashTypes() has failed. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2238"/>
        <source>%1: Adaptive Echo Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2312"/>
        <source>An error occurred while attempting to set an adaptive echo token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2318"/>
        <source>The token must contain at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="343"/>
        <source>Joining a default Buzz channel. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="756"/>
        <source>%1: Select Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2006"/>
        <source>%1: Save Attachment(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2095"/>
        <source>An error occurred while attempting to extract the attachment(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1755"/>
        <location filename="../GUI/spot-on-urls.cc" line="1368"/>
        <source>&amp;PostgreSQL Connect...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="1168"/>
        <source>%1: Neighbor Remote IP Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="151"/>
        <source>The File Encryption application is occupied. Are you sure that you wish to exit %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="174"/>
        <source>The kernel appears to be active. Closing %1 will not deactivate the kernel. Are you sure that you wish to exit %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2380"/>
        <location filename="../GUI/spot-on-d.cc" line="2473"/>
        <source>%1: SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-d.cc" line="2381"/>
        <location filename="../GUI/spot-on-d.cc" line="2474"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls-search.cc" line="562"/>
        <source>Did you prepare common credentials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls-search.cc" line="572"/>
        <location filename="../GUI/spot-on-urls.cc" line="542"/>
        <location filename="../GUI/spot-on-urls.cc" line="711"/>
        <location filename="../GUI/spot-on-urls.cc" line="838"/>
        <location filename="../GUI/spot-on-urls.cc" line="955"/>
        <location filename="../GUI/spot-on-urls.cc" line="1075"/>
        <location filename="../GUI/spot-on-urls.cc" line="1538"/>
        <location filename="../GUI/spot-on-urls.cc" line="2010"/>
        <location filename="../GUI/spot-on-urls.cc" line="2046"/>
        <location filename="../GUI/spot-on-urls.cc" line="2249"/>
        <source>Please connect to a URL database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls-search.cc" line="102"/>
        <source>&lt;html&gt;Searched for... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls-search.cc" line="538"/>
        <source> &lt;a href=&quot;&gt;&quot;&gt;Next&lt;/a&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls-search.cc" line="541"/>
        <source> &lt;a href=&quot;&lt;&quot;&gt;Previous&lt;/a&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="333"/>
        <source>Import credentials have been prepared.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="336"/>
        <source>Import credentials have not been set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="340"/>
        <source>Common credentials have been prepared.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="343"/>
        <source>Common credentials have not been set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1046"/>
        <source>Approximate URLs: %1.
Approximate content size: %2 %3.
Approximate keywords: %4.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1581"/>
        <source>%1: Creating URL Databases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1689"/>
        <source>Creating spot_on_urls_revisions_%1%2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1762"/>
        <source>One or more errors occurred while attempting to create the URL databases.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="720"/>
        <source>Are you sure that you wish to delete most of the URL databases? Your credentials will also be removed. The shared.db database will not be removed. Please note that the deletion process may require a considerable amount of time to complete. The RSS mechanism and the kernel will be deactivated. Please also verify that you have proper administrator privileges.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="754"/>
        <source>One or more errors occurred while attempting to delete the URL data. Please verify that you have correct administrator privileges.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="942"/>
        <source>One or more errors occurred while attempting to destroy the URL tables.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="969"/>
        <source>%1: Gathering URL Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1085"/>
        <source>Did you prepare URL common credentials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1094"/>
        <source>Did you prepare your URL databases and URL distillers?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1487"/>
        <source>&amp;PostgreSQL Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1549"/>
        <source>Please note that the database-preparation process may require a considerable amount of time to complete. Default URL distillers will also be created. The RSS mechanism and the kernel will be deactivated. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1789"/>
        <source>In order to save new Common Credentials, the RSS mechanism and the kernel will be deactivated. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="529"/>
        <source>An error (%1) occurred while attempting to add the specified URL domain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2085"/>
        <source>%1: Export Link As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="594"/>
        <source>%1: Deleting Orphaned URL Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="634"/>
        <source>Reviewing spot_on_keywords_%1%2 for orphaned entries. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="699"/>
        <source>Approximate orphaned keyword entries deleted: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="589"/>
        <source>Deleting orphaned URL keywords. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="847"/>
        <source>Are you sure that you wish to drop most of the URL tables? Your credentials will not be removed. The shared.db database will not be removed. Please note that the process may require a considerable amount of time to complete. The RSS mechanism and the kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="875"/>
        <source>Dropping URL tables. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="879"/>
        <source>%1: Dropping URL Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="47"/>
        <source>Deleting URL data... Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="51"/>
        <source>%1: Deleting URL Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1109"/>
        <source>Please note that the URL-import process may require a considerable amount of time to complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1577"/>
        <source>Creating URL databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1618"/>
        <source>Creating spot_on_keywords_%1%2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1650"/>
        <source>Creating spot_on_urls_%1%2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="965"/>
        <source>Gathering URL statistics. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1169"/>
        <source>Importing URLs. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="140"/>
        <source>URLs imported: %1. URLs not imported: %2. Some URLs (%3) may have been declined because of distiller rules. URLs which were not imported will remain in shared.db. The process completed in %4 second(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2524"/>
        <source>The provided credentials are correct. Please save the information!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2025"/>
        <source>Are you sure that you wish to remove the URL %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2210"/>
        <source>Are you sure that you wish to share the URL %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="554"/>
        <source>The database-correction process may require a considerable amount of time to complete. You may experience performance degradation upon completion. The RSS mechanism and the kernel will be deactivated. A brief report will be displayed after the process completes. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="562"/>
        <source>The database-correction process may require a considerable amount of time to complete. The RSS mechanism and the kernel will be deactivated. A brief report will be displayed after the process completes. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="226"/>
        <location filename="../GUI/spot-on-urls.cc" line="1912"/>
        <source>Database write error. Is urls_key_information.db properly defined?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="414"/>
        <source>Please specify at least one direction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="420"/>
        <source>Invalid domain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="430"/>
        <source>Only ftp, gopher, http, and https schemes are allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="523"/>
        <source>Unable to add the specified URL domain. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2233"/>
        <source>URL %1 shared with your friendly participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2001"/>
        <location filename="../GUI/spot-on-urls.cc" line="2055"/>
        <location filename="../GUI/spot-on-urls.cc" line="2258"/>
        <source>Invalid m_urlCommonCrypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2391"/>
        <source>Invalid permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2410"/>
        <source>Deleting URL keywords. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2414"/>
        <source>%1: Deleting URL Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1173"/>
        <source>%1: Importing URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1956"/>
        <source>%1: Select INI Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="2530"/>
        <source>The provided credentials are incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="230"/>
        <location filename="../GUI/spot-on-urls.cc" line="1916"/>
        <source>An error occurred with spoton_crypt::encryptedThenHashed().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="234"/>
        <location filename="../GUI/spot-on-urls.cc" line="1920"/>
        <source>Unable to access urls_key_information.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-urls.cc" line="1826"/>
        <location filename="../GUI/spot-on-urls.cc" line="1928"/>
        <source>Key generation failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="891"/>
        <location filename="../GUI/spot-on-urls.cc" line="1413"/>
        <source>%1: PostgreSQL Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="958"/>
        <location filename="../GUI/spot-on-urls.cc" line="1481"/>
        <source>Could not open (%1) a database connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="873"/>
        <source>A failure occurred with spoton_misc::poptasticSettings().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="991"/>
        <source>Your version of libcURL does not support POP3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="999"/>
        <source>Your version of libcURL does not support SMTP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1021"/>
        <location filename="../GUI/spot-on-e.cc" line="1663"/>
        <source>An error (%1) occurred while attempting to save the Poptastic information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2392"/>
        <location filename="../GUI/spot-on-e.cc" line="2398"/>
        <source>%1: Poptastic Incoming Connection Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2400"/>
        <location filename="../GUI/spot-on-e.cc" line="2551"/>
        <source>Failure!
Error: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2543"/>
        <location filename="../GUI/spot-on-e.cc" line="2549"/>
        <source>%1: Poptastic Outgoing Connection Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1436"/>
        <source>Are you sure that you wish to reset your Poptastic settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1802"/>
        <source>%1: Select CA File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1928"/>
        <source>%1: StarBeam Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1929"/>
        <source>&amp;Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1948"/>
        <source>An error occurred while attempting to secure the pulse size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1980"/>
        <source>%1: StarBeam Read Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1981"/>
        <source>&amp;Read Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2048"/>
        <source>Please select at least one participant for StarBeam sharing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2081"/>
        <source>The selected file is not readable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="1078"/>
        <source>Are you sure that you wish to delete the specified Poptastic account?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="2394"/>
        <location filename="../GUI/spot-on-e.cc" line="2545"/>
        <source>Test successful!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-e.cc" line="958"/>
        <source>%1: Poptastic &amp; RetroPhone Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1709"/>
        <source>&lt;i&gt;Replay activated.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1988"/>
        <source>Unable to open a connection to friends_public_keys.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="762"/>
        <source>Invalid spoton_crypt objects. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="778"/>
        <source>Are you sure that you wish to delete the selected key pair? The kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1340"/>
        <source>%1: Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1403"/>
        <source>Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1405"/>
        <source>Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1904"/>
        <source>&lt;html&gt;The participant &lt;b&gt;%1&lt;/b&gt; (%2) is requesting Forward Secrecy credentials. The participant provided an &lt;b&gt;%3:%4&lt;/b&gt; public session key. Please press the OK button if you would like to complete the exchange.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1942"/>
        <source>Peculiar spoton_crypt error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="987"/>
        <source>All of the selected participants are temporary. Please befriend some participants before attempting to establish Forward Secrecy credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="884"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="995"/>
        <source>Traditional e-mail accounts do not support Forward Secrecy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1004"/>
        <source>Some of the selected participants are temporary. Forward Secrecy credentials will not be established.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1013"/>
        <source>Please note that traditional e-mail accounts do not support Forward Secrecy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1020"/>
        <location filename="../GUI/spot-on-f.cc" line="1874"/>
        <source>%1: Forward Secrecy Algorithms Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1034"/>
        <source>Please select.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1985"/>
        <source>Error recording credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="774"/>
        <source>Are you sure that you wish to delete the selected key pair? StarBeam digest computations will be interrupted. The kernel will also be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="353"/>
        <source>Participant &lt;b&gt;%1&lt;/b&gt; (%2) is requesting Forward Secrecy credentials.&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="361"/>
        <location filename="../GUI/spot-on-f.cc" line="387"/>
        <source>&lt;html&gt;Participant %1 is requesting Forward Secrecy credentials.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1310"/>
        <source>Are you sure that you wish to lock the application? All other windows will be closed. Buzz windows will be united with the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-f.cc" line="1287"/>
        <location filename="../GUI/spot-on-urls.cc" line="2349"/>
        <source>Are you sure that you wish to access the URL %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="2025"/>
        <source>&amp;Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="744"/>
        <source>The open-library public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1974"/>
        <source>&amp;Separate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1198"/>
        <source>%1: Global Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="923"/>
        <source>The URL keys are too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1592"/>
        <source>Invalid listener / neighbor OID. Please select a listener / neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1631"/>
        <source>%1: Private Application Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1650"/>
        <source>Invalid magnet or memory failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1669"/>
        <source>Please provide a Secret that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1761"/>
        <source>An error occurred while attempting to set the private application credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1768"/>
        <source>An error (%1) occurred while deriving private application credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1258"/>
        <source>Would you like to launch the initialization wizard?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="113"/>
        <source>The passphrases must contain at least eight characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="118"/>
        <source>The answer and question must contain at least eight characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1839"/>
        <source>&amp;Copy Style Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1843"/>
        <source>&amp;Reset Widget Style Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1847"/>
        <source>Set Widget &amp;Style Sheet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1853"/>
        <source>Reset &amp;All Widget Style Sheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1409"/>
        <source>Are you sure that you wish to reset all custom widget style sheets?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1032"/>
        <source>An error (%1) occurred while attempting to generate a new certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1097"/>
        <source>The generated data could not be recorded. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1103"/>
        <source>An error (%1) occurred while attempting to record the generated data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-g.cc" line="1798"/>
        <source>Spot-On: Widget Style Sheet (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="741"/>
        <source>Read (New Window)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1145"/>
        <location filename="../GUI/spot-on-h.cc" line="1167"/>
        <location filename="../GUI/spot-on-h.cc" line="1189"/>
        <source>SCTP, if available, and TCP only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1211"/>
        <source>SCTP, if available, TCP, and UDP only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1214"/>
        <source>SO_TIMESTAMPING is not defined.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1220"/>
        <source>%1: Listener Socket Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1222"/>
        <source>SCTP socket options will be applied to a listener&apos;s socket after the socket is created. SCTP peers will also inherit some options. TCP and UDP socket options will be applied to peer sockets after connections are established. For a WebSocket listener, the socket options will be applied after the server has successfully listened.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1233"/>
        <source>%1: Neighbor Socket Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1235"/>
        <source>SCTP socket options will be applied to a socket after the socket is created and after the socket is connected. TCP and UDP socket options will be applied after connections are established.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1251"/>
        <location filename="../GUI/spot-on-h.cc" line="1253"/>
        <source>SCTP, TCP, UDP listeners only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1276"/>
        <location filename="../GUI/spot-on-h.cc" line="1278"/>
        <source>SCTP, TCP, UDP neighbors only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1286"/>
        <location filename="../GUI/spot-on-h.cc" line="1288"/>
        <source>SCTP is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1294"/>
        <source>Not available on Windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1481"/>
        <source>The Spot-On Search Engine may be accessed via &lt;a href=&quot;http://%1:%2&quot;&gt;http://%1:%2&lt;/a&gt; and &lt;a href=&quot;https://%1:%3&quot;&gt;https://%1:%3&lt;/a&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-h.cc" line="1610"/>
        <source>Error generating Web Server credentials.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_adaptiveechoprompt</name>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="36"/>
        <source>Please provide the following information. The token must contain at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="51"/>
        <source>Adaptive Echo Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="58"/>
        <source>Token &amp;Encryption Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="68"/>
        <source>&amp;Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="138"/>
        <source>Token &amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="148"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please provide the magnet in the Token field. If the magnet is not properly defined, Adaptive Echo credentials will not be extracted and the magnet will be rejected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-adaptive-echo-prompt.ui" line="151"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzPage</name>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="40"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="57"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="64"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="71"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="78"/>
        <source>Attach to the main window&apos;s Buzz page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="81"/>
        <source>Unify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="94"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="133"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="156"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="196"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="201"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="206"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="244"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="264"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="269"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="307"/>
        <source>Please type a message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-buzzpage.ui" line="319"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="137"/>
        <source>Please type a message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="513"/>
        <source>Empty kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="518"/>
        <source>The interface is not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="524"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="529"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="541"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="588"/>
        <source>An error occurred while writing to the kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="326"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="391"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="397"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="414"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="485"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="491"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="605"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="707"/>
        <source>&lt;i&gt;%1 has left (timeout) %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="793"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="838"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="328"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="416"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="487"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="493"/>
        <source>An error (%1) occurred while attempting to save the channel data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="393"/>
        <source>An error occurred while attempting to remove the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="399"/>
        <source>An error (%1) occurred while attempting to remove the channel data.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_chatwindow</name>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="134"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="123"/>
        <source>Please type a message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="210"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="548"/>
        <source>The interface is not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="216"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="555"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="221"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="301"/>
        <source>An error occurred while writing to the kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="350"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="404"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="387"/>
        <source>The Socialist Millionaire Protocol failed on %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="394"/>
        <source>The Socialist Millionaire Protocol succeeded on %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="537"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="566"/>
        <source>%1: Select StarBeam Transmit File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="570"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="585"/>
        <source>The selected file is not readable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="771"/>
        <source>An error occurred while attempting to save the StarBeam data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="775"/>
        <source>An error (%1) occurred while attempting to save the StarBeam data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="455"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="139"/>
        <source>&amp;Reset SMP Machine&apos;s Internal State (S0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="142"/>
        <source>&amp;Set SMP Secret...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="145"/>
        <source>&amp;Verify SMP Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="149"/>
        <source>&amp;Derive Gemini Pair From SMP Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="241"/>
        <source>&lt;b&gt;me&lt;/b&gt; (&lt;font color=gray&gt;%1&lt;/font&gt;)&lt;b&gt;:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="452"/>
        <source>Are you sure that you wish to access %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="42"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="49"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="92"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="162"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; width=&quot;754&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td colspan=&quot;3&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;List of Emoticons&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;20&quot; rowspan=&quot;10&quot; bgcolor=&quot;#66cc99&quot;/&gt;&lt;td width=&quot;120&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-)(-:&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;110&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;kiss&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;70&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/kiss.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td width=&quot;120&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;O:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;110&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;angel&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;70&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/angel.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:|&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;neutral&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/neutral.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; background-color:#ffffca;&quot;&gt;:-||&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;angry&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/angry.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;(t)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;phone&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/phone.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-/ &lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;confused&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/confused.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;@&amp;gt;--&amp;gt;--&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;rose&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/rose.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;8-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;cool&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/glasses-cool.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-(&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;sad&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/sad.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:&apos;(&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;crying&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/crying.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-O&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;shocked&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/shocked.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;o-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;cyclops&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/cyclops.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;C:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;skywalker&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/skywalker.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;}:)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;devil&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/devil.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;smile&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/smile.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-D&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;laugh&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/laugh.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-P&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;tongue&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/tongue.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-))&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;happy&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/happy.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;;)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;wink&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/wink.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="165"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="172"/>
        <source>Share a StarBeam.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="178"/>
        <source>Share...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="201"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Show all StarBeam mosaics.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="204"/>
        <source>&amp;StarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="263"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="271"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-chatwindow.ui" line="274"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_documentation</name>
    <message>
        <location filename="../GUI/spot-on-documentation.cc" line="62"/>
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-documentation.cc" line="80"/>
        <source>Are you sure that you wish to open %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-documentation.cc" line="84"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="31"/>
        <location filename="../UI/spot-on-documentation.ui" line="96"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="41"/>
        <source>Please press the Enter key after providing the search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="44"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="63"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="71"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="80"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="83"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="88"/>
        <source>&amp;Print Preview...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="91"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-documentation.ui" line="99"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_echo_key_share</name>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="47"/>
        <source>%1: Echo Public Key Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="65"/>
        <source>&amp;New Category...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="73"/>
        <source>&amp;Refresh Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="77"/>
        <source>Share &amp;Chat Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="80"/>
        <source>Share &amp;E-Mail Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="84"/>
        <source>Share &amp;Open Library Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="88"/>
        <source>Share &amp;Poptastic Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="91"/>
        <source>Share &amp;Rosetta Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="94"/>
        <source>Share &amp;URL Public Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="98"/>
        <source>&amp;Remove Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="628"/>
        <source>&lt;html&gt;If checked, public key pairs originating from the specified community will be saved in friends_public_keys.db.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="632"/>
        <source>&lt;html&gt;If checked, public key pairs originating from the specified community must contain valid signatures in order to be saved in friends_public_keys.db. Keys that are not signed will be temporarily accepted.&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="69"/>
        <source>&amp;Generate Specified Community</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="102"/>
        <source>&amp;Reset Input Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="959"/>
        <source>Please select a parent category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="967"/>
        <source>Please provide a Community Name that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="996"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="1007"/>
        <source>An error occurred while attempting to save the generated keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="871"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="546"/>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="610"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="427"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="423"/>
        <source>Are you sure that you wish to remove the selected item(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="681"/>
        <source>Invalid eCrypt and/or sCrypt object(s). This is a fatal error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="687"/>
        <source>Invalid m_kernelSocket object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="693"/>
        <source>The interface is not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="699"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="245"/>
        <source>%1: New Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-echo-key-share.cc" line="246"/>
        <source>&amp;Category</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_echokeyshare</name>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="126"/>
        <source>Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="131"/>
        <source>Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="136"/>
        <source>Iteration Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="121"/>
        <location filename="../UI/spot-on-echo-key-share.ui" line="164"/>
        <source>Community Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="37"/>
        <source>Shared keys will be distributed over enabled communities. The permissions assigned in this panel supersede the permissions defined in Options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="106"/>
        <source>Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="111"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="116"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="141"/>
        <source>Signatures Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="154"/>
        <source>Community &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="178"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="198"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="218"/>
        <source>&amp;Iteration Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="266"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="275"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-echo-key-share.ui" line="278"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_emailwindow</name>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="27"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="40"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="53"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="78"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="97"/>
        <source>The Rich Text option will be ignored on traditional e-mail accounts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="100"/>
        <source>&amp;Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="143"/>
        <source>Your Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="150"/>
        <source>Populate the From and To widgets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="153"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="162"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="217"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="222"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="227"/>
        <source>Neighbor OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="232"/>
        <source>Public Key Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="237"/>
        <source>Forward Secrecy Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="247"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="265"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail components in an additional layer of authentication and encryption. The first ninety-six characters will be consumed. Do remember to notify all recipients of the Gold Bug.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="268"/>
        <source>Optional Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="275"/>
        <location filename="../UI/spot-on-emailwindow.ui" line="278"/>
        <source>Secret Streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="305"/>
        <source>Forward Secrecy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="310"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="315"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="320"/>
        <source>Pure Forward Secrecy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="336"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="343"/>
        <source>&amp;Attachment(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="371"/>
        <source>Click an attachment to remove it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="384"/>
        <source>Attach...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="404"/>
        <source>Traditional e-mail supports only single attachments. Inline attachments are not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="426"/>
        <source>Sign this e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-emailwindow.ui" line="449"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="96"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="98"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="101"/>
        <source>%1: E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="160"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="162"/>
        <source>%1: Select Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="447"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="457"/>
        <source>User %1 is temporary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="537"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="568"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="580"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="603"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="623"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="637"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="647"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="659"/>
        <location filename="../GUI/spot-on-emailwindow.cc" line="705"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="539"/>
        <source>The file email.db has exceeded the specified limit. Please remove some entries and/or increase the limit via the Permissions section in Options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="570"/>
        <source>The attachment %1 cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="582"/>
        <source>The attachment %1 is too large. The maximum size of an attachment is %2 byte(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="605"/>
        <source>An error occurred while reading the attachment %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="625"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="639"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="649"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="661"/>
        <source>Please provide a Gold Bug that contains at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="707"/>
        <source>At least one of the selected e-mail recipients is temporary. Please correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="719"/>
        <source>%1: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-emailwindow.cc" line="721"/>
        <source>The Poptastic &amp; RetroPhone Settings window will be displayed. Please prepare at least one Poptastic account.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_encryptfile</name>
    <message>
        <location filename="../UI/spot-on-encryptfile.ui" line="57"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile.ui" line="68"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile.ui" line="71"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile.ui" line="76"/>
        <source>New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile.ui" line="79"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile.cc" line="40"/>
        <source>%1: File Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile.cc" line="130"/>
        <source>The current page is processing data. Abort?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile.cc" line="133"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile.cc" line="153"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_encryptfile_page</name>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="25"/>
        <source>&amp;Directory Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="35"/>
        <source>&amp;File Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="68"/>
        <source>&amp;Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="78"/>
        <source>Destination Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="85"/>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="116"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="99"/>
        <source>&amp;Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="109"/>
        <source>Origin Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="136"/>
        <source>&amp;Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="146"/>
        <source>Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="153"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="160"/>
        <source>P&amp;IN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="170"/>
        <source>PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="187"/>
        <source>&amp;Decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="200"/>
        <source>&amp;Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="230"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="280"/>
        <source>&amp;CBC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="296"/>
        <source>&amp;GCM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="306"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="343"/>
        <source>&amp;Iteration Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="409"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="416"/>
        <source>&amp;Read Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="433"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="438"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="443"/>
        <source>32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="448"/>
        <source>64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="456"/>
        <source>KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="469"/>
        <source>&amp;Sign the file(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="479"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-encryptfile-page.ui" line="486"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="566"/>
        <source>Please provide a valid destination path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="572"/>
        <source>Please provide a valid origin path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="579"/>
        <source>The destination and origin should be distinct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="585"/>
        <source>Please provide a secret that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="592"/>
        <source>Please provide a PIN.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="613"/>
        <source>Generating derived keys. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="628"/>
        <source>An error occurred while deriving keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="152"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="211"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="324"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="452"/>
        <source>File read error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="158"/>
        <source>Verifying the hash of %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="164"/>
        <source>File read failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="172"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="261"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="379"/>
        <source>Operation canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="195"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="229"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="435"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="470"/>
        <source>Hash failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="233"/>
        <source>Incorrect signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="247"/>
        <source>File seek failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="253"/>
        <source>Decrypting the file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="281"/>
        <source>Decryption failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="301"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="414"/>
        <source>gcry_kdf_derive() failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="311"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="365"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="424"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="482"/>
        <source>File write error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="327"/>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="487"/>
        <source>File open error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="371"/>
        <source>Encrypting the file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="399"/>
        <source>Encryption failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="475"/>
        <source>File seek error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="599"/>
        <source>Continue with the conversion process?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="602"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="770"/>
        <source>%1: Select File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="788"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="535"/>
        <source>The conversion process completed successfully. A signature was not discovered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-encryptfile-page.cc" line="539"/>
        <source>The conversion process completed successfully.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_forwardsecrecyalgorithmsselection</name>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="40"/>
        <source>Step 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="46"/>
        <source>&lt;b&gt;Initiate Forward Secrecy Key Exchange&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="59"/>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="226"/>
        <source>1.
2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="72"/>
        <source>Encryption Key &amp;Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="82"/>
        <source>Encryption &amp;Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="101"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="106"/>
        <source>McEliece</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="111"/>
        <source>NTRU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="116"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="148"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="153"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="158"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="163"/>
        <source>8192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="168"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="207"/>
        <source>Step 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="213"/>
        <source>&lt;b&gt;Forward Secrecy Key Exchange Completion&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="302"/>
        <source>&amp;Authentication Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-forward-secrecy-algorithms-selection.ui" line="312"/>
        <source>&amp;Encryption Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_goldbug</name>
    <message>
        <location filename="../UI/spot-on-goldbug.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-goldbug.ui" line="26"/>
        <source>&amp;Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-goldbug.ui" line="39"/>
        <source>Gold Bug Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-goldbug.ui" line="46"/>
        <location filename="../UI/spot-on-goldbug.ui" line="49"/>
        <source>Secret Streams</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_ipinformation</name>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please provide the following information. The neighbor will be disconnected if the modifications are accepted.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="51"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="61"/>
        <source>IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="68"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="88"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-ipinformation.ui" line="98"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_keyboard</name>
    <message>
        <location filename="../UI/spot-on-keyboard.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-keyboard.ui" line="78"/>
        <source>Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-keyboard.ui" line="133"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-keyboard.ui" line="153"/>
        <source>&amp;Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-keyboard.ui" line="160"/>
        <source>Secret Input</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="92"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="98"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="109"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="73"/>
        <location filename="../UI/spot-on-logviewer.ui" line="117"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="112"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-logviewer.ui" line="125"/>
        <source>Enable UI &amp;Logging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-logviewer.cc" line="41"/>
        <source>%1: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="269"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="426"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="595"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4781"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7437"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="193"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="664"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3565"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5326"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5669"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6679"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8636"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="938"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1806"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1278"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1423"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2077"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3211"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3412"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3499"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6881"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7729"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9098"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1532"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1448"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2472"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3823"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2477"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3828"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2487"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3863"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3848"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3853"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4053"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3798"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2626"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4160"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2671"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4150"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4562"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2703"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4137"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2729"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4186"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3803"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2492"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3833"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="176"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="647"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2185"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3131"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6605"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8619"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="385"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7518"/>
        <source>Hash &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="402"/>
        <source>Hash &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="431"/>
        <source>Generate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="439"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="699"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="744"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1360"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2378"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3650"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7260"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7825"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7984"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8666"/>
        <source>Context Menu Reflection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="846"/>
        <source>Last Status Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1040"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1053"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9105"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1123"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1128"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1133"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1198"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1205"/>
        <source>Resend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1263"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1926"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1268"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1397"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1617"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="245"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2133"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3378"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="255"/>
        <source>Demagnetize the link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="358"/>
        <source>Channel &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2042"/>
        <source>Institution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1283"/>
        <source>Attachment(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1288"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1680"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1833"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1931"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6786"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1949"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2101"/>
        <source>Add Institution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2202"/>
        <source>&amp;Postal Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1066"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Request e-mail from remote services (Echo, IMAP, POP3).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="720"/>
        <source>Please provide a status message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="741"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1357"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2375"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3647"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7257"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7822"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7981"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8663"/>
        <source>Context Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="880"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1141"/>
        <source>Delete Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1675"/>
        <source>Forward Secrecy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1690"/>
        <source>Pure Forward Secrecy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="861"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1607"/>
        <source>Forward Secrecy Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1754"/>
        <source>Attach...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1685"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2467"/>
        <source>Bluetooth Flags / SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2532"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3933"/>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2537"/>
        <source>Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2547"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2975"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3938"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4409"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2552"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3968"/>
        <source>SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2562"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3983"/>
        <source>Passthrough</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2736"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4209"/>
        <source>&amp;Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2753"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4231"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2758"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4236"/>
        <source>SCTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2763"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4241"/>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2768"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4246"/>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2795"/>
        <source>&amp;Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2860"/>
        <source>&amp;IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6831"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6995"/>
        <source>8192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2958"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4392"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:!SSLv3:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2986"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4420"/>
        <source>Packet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2991"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4425"/>
        <source>Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3223"/>
        <source>Adaptive Echo Tokens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3282"/>
        <source>Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3322"/>
        <source>&amp;Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3332"/>
        <source>&amp;Encryption Token Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3352"/>
        <source>&amp;Hash Token Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3464"/>
        <source>The keyword Any is supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3511"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3943"/>
        <source>Message of the Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3689"/>
        <source>Share Buzz Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3948"/>
        <source>Encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3315"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3958"/>
        <source>Adaptive Echo Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3963"/>
        <source>Adaptive Echo Token Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3973"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4330"/>
        <source>Require secure connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4989"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5024"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5054"/>
        <source>&amp;PostgreSQL Connect...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5075"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5082"/>
        <source>Prepare Databases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5102"/>
        <source>Remove orphaned database entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5105"/>
        <source>Correct Databases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5129"/>
        <source>Common Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5156"/>
        <source>Common credentials have not been set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5182"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5206"/>
        <source>&amp;Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5223"/>
        <source>P&amp;IN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5323"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Generate encryption and hash keys and save the results along with relevant information.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5342"/>
        <source>Import Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5369"/>
        <source>Import credentials have not been set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5391"/>
        <source>&amp;INI Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5422"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1523"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5429"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="143"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="186"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="657"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1513"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6625"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8629"/>
        <source>Your Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="258"/>
        <source>Buzz Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="279"/>
        <source>Magnetize Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="284"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="289"/>
        <source>Remove All Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="314"/>
        <source>Buzz Channel Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="351"/>
        <source>Buzz Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="395"/>
        <source>Buzz Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="761"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Secret Streams. The activated entry will be applied to the currently-selected participant.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="764"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1645"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1648"/>
        <source>Secret Streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="923"/>
        <source>Please type a message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1148"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1162"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please refresh after changing. Valid values lie in the interval [25, 999999999].&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1165"/>
        <source> Letters Per Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1638"/>
        <source>Optional Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1936"/>
        <source>Recipient Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2140"/>
        <source>Post Office Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2195"/>
        <source>Post Office Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2212"/>
        <source>Post Office Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2572"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3993"/>
        <source>Private Application Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2577"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4003"/>
        <source>Socket Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2611"/>
        <source>The uniqueness of a listener is defined by its local IP, local port, scope ID, and transport. TCP and WebSocket sockets are governed by the TCP protocol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2661"/>
        <source>Listener IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2713"/>
        <source>Listener Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2773"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4251"/>
        <source>WebSocket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2792"/>
        <source>Allow other UDP services to bind to the same address and port. Ignored on Windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2961"/>
        <source>Listener SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3161"/>
        <source>Account Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3467"/>
        <source>Allowed IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3696"/>
        <source>Items &amp;Displayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3706"/>
        <source>Maximum number of list entries which will be displayed. Setting will not be retained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3713"/>
        <source>25</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3718"/>
        <source>50</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3723"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3728"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3998"/>
        <source>Silence Time (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4074"/>
        <source>The uniqueness of a neighbor is defined by its proxy hostname, proxy port, remote IP, remote port, scope ID, and transport. TCP and WebSocket sockets are governed by the TCP protocol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4089"/>
        <source>Neighbor IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4170"/>
        <source>Neighbor Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4395"/>
        <source>Neighbor SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4572"/>
        <source>Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4609"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4632"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4749"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4976"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please consider installing PostgreSQL. Although SQLite is fully supported, PostgreSQL offers improved performance as well as networking capabilities. Please visit &lt;a href=&quot;https://www.postgresql.org/download&quot;&gt;https://www.postgresql.org/download&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5216"/>
        <source>Common Credentials Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5233"/>
        <source>Common Credentials PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5401"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5546"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5570"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5587"/>
        <source>Not Used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5577"/>
        <source>&amp;Salt (Hex)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5628"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5635"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Compute a salted hash of the provided passphrase and compare the result with the hash contained within the specified INI file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5638"/>
        <source>Verify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5659"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5666"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Generate an encryption key and save the result along with relevant information.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5690"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5697"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import URL data from the shared.db database.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5700"/>
        <source>Import URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5874"/>
        <source>| 1 |</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5915"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6056"/>
        <source>&amp;Secure Memory Pool Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6102"/>
        <source>Spot-On-Kernel &amp;Executable Absolute Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6112"/>
        <source>Spot-On-Kernel File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6153"/>
        <source>If PID is -1, please verify that libspoton is current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6188"/>
        <source>The below cryptographic algorithms will be applied to the various communication protocols. Some protocols may have additional restrictions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6289"/>
        <source>Congestion &amp;Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6315"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, packet digests will be stored in non-volatile memory. Please consider increasing the Kernel Cache Object Lifetime value in the Time page of the Options window.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6598"/>
        <source>Passphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6652"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9330"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6672"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9347"/>
        <source>Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6776"/>
        <source>Key Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6781"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6796"/>
        <source>Base-64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7020"/>
        <source>McEliece</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7403"/>
        <source>StarBeam Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7538"/>
        <source>StarBeam Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7555"/>
        <source>StarBeam Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7775"/>
        <source>Absolute Directory Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7917"/>
        <source>Computed SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7922"/>
        <source>Expected SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8108"/>
        <source>Read Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8287"/>
        <source>Absolute File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fragmented StarBeams allow for the fragmentation of a mosaic (file) into a number of N unique pulses, where N is the number of active network connections. The standard StarBeam transfers a particular pulse over each network connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8436"/>
        <source>&amp;Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8747"/>
        <source>URL Distillers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8768"/>
        <source>Acceptable examples: ftp:, gopher:, http:, https:, https://www.nasa.gov, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8838"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8908"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8978"/>
        <source>Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8843"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8913"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8983"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8873"/>
        <source>RSS interprets the Import settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9029"/>
        <source>Domain Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9510"/>
        <source>&amp;Log Viewer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9523"/>
        <source>&amp;Rosetta...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9547"/>
        <source>&amp;Export Public Keys...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9552"/>
        <source>&amp;Import Public Keys...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9580"/>
        <source>&amp;File Encryption...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9605"/>
        <source>&amp;Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9617"/>
        <source>&amp;About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9649"/>
        <source>&amp;Neighbor Summary Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9526"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9732"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reclaim storage occupied by empty database pages.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9600"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9608"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9625"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9630"/>
        <source>Purge &amp;Ephemeral Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9638"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6021"/>
        <source>&amp;External IP Retrieval Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6038"/>
        <source>30 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6043"/>
        <source>60 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6048"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6263"/>
        <source>&amp;Congestion Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9585"/>
        <source>Clear Clipboard &amp;Buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9588"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7064"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7089"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6632"/>
        <source>&amp;Question/Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6639"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9323"/>
        <source>&amp;Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6659"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9337"/>
        <source>&amp;Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7025"/>
        <source>NTRU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6963"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6898"/>
        <source>Key &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="466"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="469"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="959"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="962"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7327"/>
        <source>One-Time-Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9575"/>
        <source>&amp;Minimal Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7376"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7423"/>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7545"/>
        <source>Encryption &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7618"/>
        <source>&amp;Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7765"/>
        <source>&amp;Destination Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7857"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A lock request may not be immediate because of the asynchronous nature of Spot-On. If a file is locked, its write permissions will be revoked.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7892"/>
        <source>Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7897"/>
        <source>Percent Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7907"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8083"/>
        <source>Total Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8103"/>
        <source>SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8098"/>
        <source>Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8450"/>
        <source>&amp;Distribution Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9487"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9531"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9534"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9539"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9542"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7447"/>
        <source>Generate Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7452"/>
        <source>Generate MAC Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2239"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5267"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5470"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6223"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6482"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7562"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2229"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5247"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5450"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6203"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6462"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7508"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8327"/>
        <source> Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3813"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2497"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3838"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2512"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3888"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2517"/>
        <source>Use Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2857"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Record the current external IP address in the listener&apos;s certificate. Please do not use this option if you have a dynamic IP address.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2873"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4343"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6338"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2887"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4357"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6363"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2897"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4367"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6373"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6821"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6985"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2817"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4274"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="121"/>
        <source>&amp;Common Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="220"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7806"/>
        <source> MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1344"/>
        <source>New Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5436"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6119"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7782"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8294"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1470"/>
        <source>&amp;Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="59"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="62"/>
        <source>Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="304"/>
        <source>Channel &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="556"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="831"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1597"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8733"/>
        <source>Neighbor OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="836"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1602"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8738"/>
        <source>Public Key Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="935"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; width=&quot;754&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td colspan=&quot;3&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;List of Emoticons&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;20&quot; rowspan=&quot;10&quot; bgcolor=&quot;#66cc99&quot;/&gt;&lt;td width=&quot;120&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-)(-:&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;110&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;kiss&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;70&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/kiss.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td width=&quot;120&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;O:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;110&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;angel&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;70&quot; bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/angel.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:|&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;neutral&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/neutral.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt; background-color:#ffffca;&quot;&gt;:-||&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;angry&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/angry.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;(t)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;phone&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/phone.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-/ &lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;confused&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/confused.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;@&amp;gt;--&amp;gt;--&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;rose&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/rose.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;8-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;cool&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/glasses-cool.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-(&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;sad&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/sad.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:&apos;(&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;crying&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/crying.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-O&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;shocked&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/shocked.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;o-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;cyclops&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/cyclops.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;C:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;skywalker&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/skywalker.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;}:)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;devil&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/devil.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;smile&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/smile.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-D&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;laugh&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/laugh.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-P&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;tongue&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/tongue.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;:-))&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;happy&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/happy.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;;)&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt;&quot;&gt;wink&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;td bgcolor=&quot;#ffffca&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/emoticons/wink.png&quot;/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1069"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1098"/>
        <source>&amp;Read / &amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1225"/>
        <source>Save Attachment(s)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1293"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1706"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3540"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1298"/>
        <source>Message Digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1303"/>
        <source>Receiver / Sender Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1308"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6791"/>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1313"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1467"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The Rich Text option will be ignored on traditional e-mail accounts. If enabled, an HTML representation of the Message text will be included in the e-mail bundle.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1520"/>
        <source>Populate the From widget with Poptastic accounts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1713"/>
        <source>&amp;Attachment(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1741"/>
        <source>Click an attachment to remove it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1774"/>
        <source>Traditional e-mail supports only single attachments. Inline attachments are not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1796"/>
        <source>Sign this e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1854"/>
        <source>Mail sent via Pure Forward Secrecy shall not be archived.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1872"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1966"/>
        <source>&amp;day(s) will be purged automatically by the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1991"/>
        <source>Institutions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2047"/>
        <source>Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2052"/>
        <source>Postal Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2057"/>
        <source>Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2070"/>
        <source>Copy Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2303"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2306"/>
        <source>Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2401"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3742"/>
        <source>Setting will not be retained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2557"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3978"/>
        <source>Lane Width (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2567"/>
        <source>Randomness Source (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2590"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2831"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4288"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2836"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4293"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2925"/>
        <source>&amp;Day(s) Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3079"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3116"/>
        <source>The account name and the account password must contain at least thirty-two characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3177"/>
        <source>&amp;One-Time Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3244"/>
        <source>Adaptive echo tokens are applied to all defined listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3287"/>
        <source>Token Encryption Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3292"/>
        <source>Token Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3300"/>
        <source>The token must contain at least ninety-six characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3590"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3593"/>
        <source>Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3676"/>
        <source>Copy Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2404"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3745"/>
        <source>Pause Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1894"/>
        <source>Duplicate letters denote institution and participant carriers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3818"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3843"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3868"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3873"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3898"/>
        <source>Allow Certificate Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3908"/>
        <source>Bytes Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3913"/>
        <source>Bytes Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3918"/>
        <source>SSL Session Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3151"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3923"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="851"/>
        <source>Gemini Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="856"/>
        <source>Gemini Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1635"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail components in an additional layer of authentication and encryption. The first ninety-six characters will be consumed. Do remember to notify all recipients of the Gold Bug.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3928"/>
        <source>Account Authenticated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3953"/>
        <source>Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3988"/>
        <source>Wait-For-Bytes-Written (Milliseconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4008"/>
        <source>Buffered Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4199"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4202"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4314"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On will record peer certificates during initial connections. Subsequent connections will cause Spot-On to inspect peer certificates. If there are discrepancies between recorded certificates and transmitted certificates, Spot-On will sever the connections. Enable this option if you would like Spot-On to ignore discrepancies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4333"/>
        <source>&amp;Require SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4719"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4833"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4836"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5774"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4895"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5933"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5936"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5189"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;You may access the PostgreSQL URL database from multiple devices if common credentials are prepared. The SQLite URL database also requires common credentials. The credentials are stored in an SQLite database.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5560"/>
        <source>Hash (Hex)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5902"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5912"/>
        <source>Please press the Enter key after providing the search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6066"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Setting a value of zero will disable the secure memory pool. Please restart the kernel upon changes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6348"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A value of zero disables SSL/TLS between the UI and the kernel. Please restart the kernel if this option is changed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6385"/>
        <source>Secondary Storage Maximum Page Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6392"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The maximum page count along with the page size determine the maximum size of the congestion_control.db SQLite database. The page size is usually 4096 bytes. Therefore, a maximum page count of 100,000 will result in an approximate maximum database size of 391 MiB.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6395"/>
        <source> Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6447"/>
        <source>The below cryptographic algorithms will be applied to authentication and encryption of local storage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6585"/>
        <source>Minimum of 8 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6592"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6649"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6669"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6691"/>
        <source>Virtual keyboard via double-click.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7044"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, a confirmation prompt is displayed whenever the passphrase or question/answer is/are updated. If the confirmation prompt is confirmed, new key pairs will be generated.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7170"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7173"/>
        <source>StarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7231"/>
        <source>&amp;Magnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7292"/>
        <source>Please do not remove magnets until the respective StarBeams have completed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7332"/>
        <source>Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7496"/>
        <source>Please verify that the credentials are distinct!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7643"/>
        <source>Novas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7664"/>
        <source>Please do not remove novas until the respective StarBeams have completed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7739"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7927"/>
        <source>Computed SHA3-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7932"/>
        <source>Expected SHA3-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7937"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8123"/>
        <source>ETA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8016"/>
        <source>Modifying the pulse size of an active or partially-transmitted StarBeam will result in loss of data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8113"/>
        <source>Fragmented</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8118"/>
        <source>SHA3-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8154"/>
        <source>Rewind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8182"/>
        <source>Add Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8260"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Place each pulse in an encrypted envelope. Please remember to notify all recipients of the key information.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7697"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8253"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8263"/>
        <source>Nova</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8317"/>
        <source>&amp;Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8365"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8368"/>
        <source>URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8433"/>
        <source>Activate or deactivate the distribution of URLs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8489"/>
        <source>Web Server Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8496"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A positive port value will enable the Spot-On Search Server (SOSS); an active kernel is also required. Please modify the current port or press the Enter key while keyboard focus is on the Web Server Port widget for new credentials. A port value of zero will deactivate the Spot-On Search Server (SOSS).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8515"/>
        <source>Maximum Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8535"/>
        <source>Allow access to locally-stored content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8538"/>
        <source>&amp;Local Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8545"/>
        <source>&amp;PostgreSQL Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8558"/>
        <source>Web Server Information Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8803"/>
        <source>The kernel interprets the Download settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8943"/>
        <source>The kernel interprets the Upload settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9019"/>
        <source>&amp;Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9144"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9290"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9375"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9518"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9557"/>
        <source>Export &amp;Listeners...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9562"/>
        <source>Import &amp;Neighbors...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9567"/>
        <source>StarBeam &amp;Analyzer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9597"/>
        <source>Poptastic &amp;&amp; RetroPhone Settin&amp;gs...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9622"/>
        <source>Echo Public Key &amp;Share...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9635"/>
        <source>&amp;Statistics...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9729"/>
        <source>&amp;Vacuum SQLite Databases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9737"/>
        <source>No&amp;tifications...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9742"/>
        <source>New &amp;Global Name...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9747"/>
        <source>Add &amp;Participant...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9752"/>
        <source>&amp;Documentation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9757"/>
        <source>S&amp;MP...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9762"/>
        <source>R&amp;elease Notes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5376"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The INI path may reference the absolute path of the Dooble.ini file. On Unix systems, this file usually resides in ~/.dooble. On Windows systems, the Dooble.ini file usually resides in the directory that also houses the Dooble.exe file. The credentials are stored in an SQLite database. Please note that both Dooble and Spot-On must reference the same shared.db database.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5771"/>
        <source>Please provide complete keywords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9658"/>
        <source>&amp;RSS...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5781"/>
        <source>&amp;Discover!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6273"/>
        <source>The congestion cost applies to volatile memory only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6318"/>
        <source>&amp;Secondary Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6908"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7047"/>
        <source>&amp;Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6930"/>
        <source>ECDSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6935"/>
        <source>EdDSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6953"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8310"/>
        <source>&amp;Fragment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8464"/>
        <source>Linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8852"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9058"/>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9437"/>
        <source>&amp;Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9669"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9680"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9691"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9702"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9713"/>
        <source>S&amp;tarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9724"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6940"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7015"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6945"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7030"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6888"/>
        <source>&amp;Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6925"/>
        <source>DSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7690"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8241"/>
        <source>Novas must contain at least forty-eight characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8068"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7902"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8078"/>
        <source>Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4579"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="341"/>
        <source>&amp;Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4454"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4589"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4599"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3141"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4616"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3424"/>
        <source>Allowed IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4499"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4504"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4509"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5995"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6146"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6156"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6358"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6727"/>
        <source>Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6575"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9513"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2457"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6133"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="729"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="841"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1273"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2462"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3808"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8088"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2482"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3858"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2639"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4105"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="684"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="689"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="704"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="821"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1587"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8723"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2507"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="694"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2653"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2279"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3012"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3204"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3405"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3492"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4671"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4774"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7608"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7722"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9084"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3174"/>
        <source>If checked, the account will be removed after a client successfully authenticates itself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3673"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4726"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6166"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5287"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="5490"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6502"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2892"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4362"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6368"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6816"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6980"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6826"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6990"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6836"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7000"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6525"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5533"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6565"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6615"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9270"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8782"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9042"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8922"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9074"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="274"/>
        <source>Demagnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="321"/>
        <source>&amp;Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="621"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8593"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="826"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1318"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="1592"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="2582"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4013"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7342"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7942"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8128"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8233"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8728"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="1410"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2542"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3903"/>
        <source>Certificate SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5038"/>
        <source>PostgreSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="5043"/>
        <source>SQLite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7337"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8228"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2272"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="7442"/>
        <source>Generate Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7796"/>
        <source>&amp;Maximum Mosaic Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7955"/>
        <source>&amp;Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8073"/>
        <source>Percent Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="7912"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="8093"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8343"/>
        <source>Transmit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2502"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2522"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3878"/>
        <source>Max. Buffer Size (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2527"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="3883"/>
        <source>Max. Content Length (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="3893"/>
        <source>Uptime (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="4317"/>
        <source>&amp;Allow Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6331"/>
        <source>&amp;Log Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="6426"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="6697"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9283"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="2948"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="4382"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="8277"/>
        <location filename="../UI/spot-on-controlcenter.ui" line="9422"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9433"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9464"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9502"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-controlcenter.ui" line="9505"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_neighbor_statistics</name>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="14"/>
        <source>Spot-On: Neighbor Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="50"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="55"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="73"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="81"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-neighborstatistics.ui" line="84"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_neighborstatistics</name>
    <message>
        <location filename="../GUI/spot-on-neighborstatistics.cc" line="116"/>
        <source>Cert. Effective Date: %1
Cert. Expiration Date: %2
Cert. Issuer Organization: %3
Cert. Issuer Common Name: %4
Cert. Issuer Locality Name: %5
Cert. Issuer Organizational Unit Name: %6
Cert. Issuer Country Name: %7
Cert. Issuer State or Province Name: %8
Cert. Serial Number: %9
Cert. Subject Organization: %10
Cert. Subject Common Name: %11
Cert. Subject Locality Name: %12
Cert. Subject Organizational Unit Name: %13
Cert. Subject Country Name: %14
Cert. Subject State or Province Name: %15
Cert. Version: %16</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_notifications_window</name>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="24"/>
        <source>&amp;Activate window on events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="31"/>
        <source>&amp;Monitor events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="70"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="76"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="85"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="88"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-notificationswindow.ui" line="93"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_options</name>
    <message>
        <location filename="../UI/spot-on-options.ui" line="76"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="93"/>
        <source>Everaldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="103"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="108"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="150"/>
        <source>Tab Icon &amp;Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="167"/>
        <source>16x16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="172"/>
        <source>24x24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="177"/>
        <source>32x32</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="182"/>
        <source>64x64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="210"/>
        <source>Tab &amp;Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="227"/>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="232"/>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="242"/>
        <source>West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="265"/>
        <location filename="../UI/spot-on-options.ui" line="1581"/>
        <source>Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="292"/>
        <source>Join the first &amp;common channel after the kernel is activated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="373"/>
        <source>&amp;Display participant popups automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="442"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="462"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="467"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="536"/>
        <source>&amp;Timestamps (remote events only).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="810"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enabling this feature may cause catastrophic database corruption if the application aborts during an import.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="813"/>
        <source>&amp;Disable interface synchronous SQLite writes on import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="881"/>
        <source>&amp;results per page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1066"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Setting a value of zero will disable the secure memory pool. Please restart the application upon changes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1112"/>
        <source>&amp;Populate statistics every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1168"/>
        <source>P&amp;urge kernel cache container(s) every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1646"/>
        <source>&amp;Accept only signed geminis, messages, and status bulletins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1685"/>
        <location filename="../UI/spot-on-options.ui" line="1784"/>
        <source>Allow &amp;forward secrecy requests.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1705"/>
        <location filename="../UI/spot-on-options.ui" line="2143"/>
        <source>&amp;Open clicked links in the appropriate Web browser
as defined by the user&apos;s environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1713"/>
        <source>&amp;Sign forward secrecy replies
and requests, geminis, messages,
and status bulletins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1755"/>
        <source>&amp;Accept only signed letters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1840"/>
        <source>&amp;Reject C/O letters without signatures. The setting
does not apply to data destined for institutions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1972"/>
        <source>Periodically p&amp;ublish plaintext connection information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2210"/>
        <source>&amp;Periodically broadcast scrambled messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="342"/>
        <location filename="../UI/spot-on-options.ui" line="1615"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="237"/>
        <source>South</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="363"/>
        <location filename="../UI/spot-on-options.ui" line="570"/>
        <location filename="../UI/spot-on-options.ui" line="1353"/>
        <source>Alternating row &amp;colors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="383"/>
        <source>Enable &amp;emoticons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="430"/>
        <source>&amp;On-top dialogs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1178"/>
        <source> seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="549"/>
        <location filename="../UI/spot-on-options.ui" line="1728"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="580"/>
        <source>&amp;Refresh containers after launch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="598"/>
        <source>&amp;Retrieve e-mail every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="605"/>
        <source> minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="636"/>
        <location filename="../UI/spot-on-options.ui" line="1889"/>
        <source>Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="706"/>
        <location filename="../UI/spot-on-options.ui" line="1982"/>
        <source>Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="733"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1363"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enabling this feature may cause catastrophic database corruption if the kernel aborts during a download.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1366"/>
        <source>&amp;Disable kernel synchronous SQLite writes on download.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="909"/>
        <location filename="../UI/spot-on-options.ui" line="2154"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="58"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="64"/>
        <source>&amp;Activate Notifications window on events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="98"/>
        <source>Meego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="131"/>
        <source>&amp;Monitor events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="138"/>
        <source>&amp;Play sounds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="304"/>
        <location filename="../UI/spot-on-options.ui" line="392"/>
        <source>Maximum Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="427"/>
        <source>Please close open windows after modifying this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="495"/>
        <location filename="../UI/spot-on-options.ui" line="662"/>
        <location filename="../UI/spot-on-options.ui" line="748"/>
        <source>&amp;Populate the table every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="505"/>
        <location filename="../UI/spot-on-options.ui" line="672"/>
        <location filename="../UI/spot-on-options.ui" line="758"/>
        <location filename="../UI/spot-on-options.ui" line="1122"/>
        <location filename="../UI/spot-on-options.ui" line="1306"/>
        <source> second(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="825"/>
        <location filename="../UI/spot-on-options.ui" line="1479"/>
        <source>A large value may impede the process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="838"/>
        <source>&amp;maximum keywords accepted during an import via the interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="935"/>
        <source>&amp;GeoIP Data Path IPv4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="945"/>
        <source>GeoIP IPv4 File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="952"/>
        <location filename="../UI/spot-on-options.ui" line="983"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="966"/>
        <source>&amp;GeoIP Data Path IPv6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="976"/>
        <source>GeoIP IPv6 File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="994"/>
        <location filename="../UI/spot-on-options.ui" line="1007"/>
        <source>External IP URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1001"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please specify a valid URL. The URL must return an IP address only. Press the Enter key to save.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1004"/>
        <source>https://api.ipify.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1021"/>
        <source>&amp;External IP Retrieval Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1038"/>
        <source>30 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1043"/>
        <source>60 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1048"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1056"/>
        <source>&amp;Secure Memory Pool Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1097"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the SQLite synchronous command to off on dispensable database writes. For example, Kernel statistics are considered nonessential.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1100"/>
        <source>Limit SQLite synchronization.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1138"/>
        <source>Increasing the timer value will impede current display statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1214"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1224"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:!SSLv3:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1227"/>
        <source>SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1234"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1241"/>
        <source>Display a list of ciphers produced by the provided SSL Control String.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1244"/>
        <source>Test...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1253"/>
        <source>&amp;Terminate kernel process on UI exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1263"/>
        <source>StarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1284"/>
        <source>&amp;Automatically verify digests.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1296"/>
        <source>&amp;Populate tables every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1337"/>
        <source>&amp;Remove one-time magnets upon exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1378"/>
        <source>A value of zero disables the timeout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1381"/>
        <source> Milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1397"/>
        <source>&amp;PostgreSQL URL-distribution kernel query timeout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1430"/>
        <source>Please review your lane widths before increasing this value.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1446"/>
        <source>&amp;URL(s) batched per URL distribution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1492"/>
        <source>&amp;maximum keywords accepted during an import via the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1529"/>
        <source>Miscellaneous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1535"/>
        <source>Option := Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1560"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1575"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1602"/>
        <source>Save valid Buzz magnets shared via direct connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1605"/>
        <source>Accept shared &amp;magnets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1636"/>
        <source>Accept &amp;geminis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1662"/>
        <source>Accept shared StarBeam &amp;magnets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1672"/>
        <location filename="../UI/spot-on-options.ui" line="1771"/>
        <location filename="../UI/spot-on-options.ui" line="2324"/>
        <source>Accept shared public &amp;keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1695"/>
        <source>Broadcast odd messages at odd times. Please note that this option will advertise your presence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1698"/>
        <source>&amp;Impersonate me.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1799"/>
        <source>&amp;Limit the size of email.db to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1809"/>
        <source> MiB.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1969"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;External IP information is required, save for local-area listeners.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2009"/>
        <source>&amp;Accept published local listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2604"/>
        <source>Discard Poptastic forward secrecy messages if they have expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2790"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1915"/>
        <source>&amp;Limit connections to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1925"/>
        <source>Limit the number of connections per client IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2025"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2028"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2041"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2044"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2060"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2072"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2086"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2091"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2096"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2416"/>
        <source>Discard forward secrecy messages if they have expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2510"/>
        <source>Specifies the lifetime of packet digests (congestion control, e-mail requests, geminis).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="792"/>
        <location filename="../UI/spot-on-options.ui" line="2122"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1857"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1873"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The kernel is responsible for signing forward secrecy requests and responses. Please avoid toggling this checkbox until messages have been processed by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1876"/>
        <source>Sign &amp;forward secrecy replies and requests.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2181"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please enable this option if you would like to force kernel registration. By forcing kernel registration, an existing kernel process that Spot-On is aware of will be deactivated. You may wish to use this option if a kernel was not deactivated properly.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2184"/>
        <source>&amp;Force kernel registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2194"/>
        <source>&amp;Launch the kernel after user authentication.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2207"/>
        <source>Please note that this option will advertise your presence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2217"/>
        <source>Automatically share the private authentication and encryption keys with a kernel process. If this option is disabled, the user interface will provide reminders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2236"/>
        <source>&amp;Super Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2246"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, messages that are interpreted correctly will be echoed. Please note that this option will advertise your presence. This option does not supersede a half-echo agreement.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2256"/>
        <source>Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2261"/>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1347"/>
        <location filename="../UI/spot-on-options.ui" line="2287"/>
        <source>URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="1941"/>
        <source>client(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2220"/>
        <source>&amp;Share private authentication and encryption keys
with the kernel process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2308"/>
        <source>&amp;Accept only signed URLs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2331"/>
        <source>Sign &amp;URLs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2350"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2362"/>
        <source>Values have units of seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2369"/>
        <source>Highlight chat messages if they have expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2381"/>
        <source>&amp;Chat Time Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2428"/>
        <source>&amp;Forward Secrecy Time Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2463"/>
        <source>Discard calling data if it has expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2475"/>
        <source>&amp;Gemini Time Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2522"/>
        <source>Kernel &amp;Cache Object Lifetime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2557"/>
        <source>Specifies the interval at which the kernel will transmit URL data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2569"/>
        <source>Kernel &amp;URL Dispatcher Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2616"/>
        <source>&amp;Poptastic Forward Secrecy Time Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2651"/>
        <source>Discard Poptastic calling data if it has expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2663"/>
        <source>Poptastic Gemini Time &amp;Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2698"/>
        <source>Specifies the interval at which e-mail is retrieved via the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2710"/>
        <source>&amp;Retrieve Mail Time Delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2753"/>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2779"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-options.ui" line="2787"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_pageviewer</name>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="102"/>
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="105"/>
        <source>%1: Page Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="228"/>
        <source>Copy &amp;Last Hovered Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="240"/>
        <source>Copy &amp;Link Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="152"/>
        <location filename="../GUI/spot-on-pageviewer.cc" line="163"/>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-pageviewer.cc" line="177"/>
        <location filename="../GUI/spot-on-pageviewer.cc" line="423"/>
        <source>%1 KiB, Compressed %2 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="22"/>
        <location filename="../UI/spot-on-pageviewer.ui" line="37"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="47"/>
        <source>&amp;Revision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="117"/>
        <location filename="../UI/spot-on-pageviewer.ui" line="182"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="127"/>
        <source>Please press the Enter key after providing the search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="130"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="149"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="157"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="166"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="169"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="174"/>
        <source>&amp;Print Preview...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="177"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-pageviewer.ui" line="185"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_passwordprompt</name>
    <message>
        <location filename="../UI/spot-on-password-prompt.ui" line="36"/>
        <source>Please provide the following credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-password-prompt.ui" line="48"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-password-prompt.ui" line="58"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-password-prompt.ui" line="65"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-password-prompt.ui" line="78"/>
        <source>Account Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_poptasticretrophonesettings</name>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="44"/>
        <source>&amp;Query the incoming server(s) every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="54"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A value of zero disables the periodic query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="57"/>
        <source> seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="70"/>
        <source>&amp;Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="80"/>
        <source> messages per query.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="113"/>
        <source>&amp;Certificate Authority Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="123"/>
        <source>Certificate Authority File Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="130"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="141"/>
        <source>&amp;Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="161"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="185"/>
        <source>&amp;Chat Primary Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="205"/>
        <source>&amp;E-Mail Primary Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="258"/>
        <source>Account Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="264"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="300"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="347"/>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="778"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="357"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="367"/>
        <source>Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="374"/>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="791"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="384"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="421"/>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="610"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="434"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="510"/>
        <source>&amp;Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="538"/>
        <source>Incoming Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="545"/>
        <source>&amp;Authentification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="583"/>
        <source>Incoming Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="590"/>
        <source>Incoming Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="643"/>
        <source>Outgoing Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="653"/>
        <source>Outgoing Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="660"/>
        <source>Outgoing Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="667"/>
        <source>&amp;Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="680"/>
        <source>Outgoing Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="690"/>
        <source>Incoming Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="743"/>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="835"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="804"/>
        <source>&amp;SSL/TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="857"/>
        <source>&amp;Verify Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="884"/>
        <source>&amp;Verify Peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="911"/>
        <source>&amp;Local Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="921"/>
        <source>localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="924"/>
        <source>Local Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="931"/>
        <source>&amp;Remove Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Attempt to remove retrieved entries from the remote server.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-poptastic-retrophone-settings.ui" line="973"/>
        <source>Save Account</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_postgresqlconnect</name>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="36"/>
        <source>Please provide the following information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="53"/>
        <source>&amp;SSL/TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="78"/>
        <source>&amp;Database Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="88"/>
        <source>PostgreSQL Database Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="95"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="105"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="112"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="125"/>
        <source>Account Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="132"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="191"/>
        <source>Connection Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="142"/>
        <source>localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="145"/>
        <source>Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="152"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="175"/>
        <source>Connection &amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="185"/>
        <source>Please separate options with semicolons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-postgresql-connect.ui" line="188"/>
        <source>connect_timeout=10;sslmode=verify-full</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_private_application_credentials</name>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="36"/>
        <source>Please remember to enable the passthrough mechanism on the listener / neighbor. A secret of at least sixteen characters is expected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="51"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="61"/>
        <source>Private Applications Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="68"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="78"/>
        <source>&amp;Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="148"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please enter the magnet in the Secret field. If the magnet is not properly defined, credentials will not be extracted and the magnet will be rejected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="151"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-private-application-credentials.ui" line="158"/>
        <source>&amp;Iteration Count</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rosetta</name>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="42"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2075"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="59"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="719"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="188"/>
        <location filename="../UI/spot-on-rosetta.ui" line="259"/>
        <location filename="../UI/spot-on-rosetta.ui" line="633"/>
        <location filename="../UI/spot-on-rosetta.ui" line="726"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="52"/>
        <source>Your Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="79"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="694"/>
        <source>Contact Bundle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="367"/>
        <source>&amp;Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="387"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="142"/>
        <location filename="../UI/spot-on-rosetta.ui" line="433"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="122"/>
        <source>Decrypt / Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="132"/>
        <source>Decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="181"/>
        <location filename="../UI/spot-on-rosetta.ui" line="545"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="212"/>
        <source>Decrypt Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="277"/>
        <source>From:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="356"/>
        <source>Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="416"/>
        <source>Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="459"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="479"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="505"/>
        <source>&amp;Sign message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="559"/>
        <source>Create a Desktop copy of the message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="562"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="569"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="680"/>
        <source>Add Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="796"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="817"/>
        <source>Clear Clipboard Buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="820"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="825"/>
        <source>&amp;Import GPG Keys...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="830"/>
        <source>Remove GPG Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="220"/>
        <location filename="../UI/spot-on-rosetta.ui" line="594"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="82"/>
        <source>Copy Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="195"/>
        <location filename="../UI/spot-on-rosetta.ui" line="552"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="772"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="801"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="804"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="809"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="812"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="266"/>
        <location filename="../UI/spot-on-rosetta.ui" line="640"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="394"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="586"/>
        <source>Encrypt Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="766"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="782"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta.ui" line="793"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="56"/>
        <source>%1: Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="655"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="680"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="714"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="788"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="807"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="820"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="830"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="843"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="858"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="932"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="948"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="958"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1004"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1235"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1437"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1452"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1511"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1664"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1749"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1835"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1955"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2053"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2063"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2128"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1750"/>
        <source>The rosetta public key is too long (%1 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="845"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="60"/>
        <source>The GnuPG Made Easy library is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="77"/>
        <source>Copy My &amp;Rosetta Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="81"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1188"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1191"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1196"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1216"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1815"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="424"/>
        <source>spoton_rosetta::gpgEncrypt(): error (%1) raised.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="453"/>
        <source>%1: GPG Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="454"/>
        <source>&amp;GPG Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="681"/>
        <source>Please do not add personal GPG keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="747"/>
        <source>GPGME error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="772"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="775"/>
        <source>A cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="778"/>
        <source>Unable to access the database friends_public_keys.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="860"/>
        <source>Invalid key type. Expecting &apos;rosetta&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="885"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="910"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1860"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2013"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="934"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="950"/>
        <source>Invalid &apos;rosetta&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="960"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1006"/>
        <source>An error occurred while attempting to save the friendship bundle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1119"/>
        <source>Invalid signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1218"/>
        <source>spoton_rosetta::slotConvertDecrypt(): error (%1) raised.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1391"/>
        <source>Empty signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="2009"/>
        <source>Are you sure that you wish to remove your GPG keys? The keys will not be removed from the GPG ring.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1203"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1405"/>
        <source>Message was signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1543"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1837"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2065"/>
        <source>Invalid item data. This is a serious flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1549"/>
        <source>Please provide an actual message!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1558"/>
        <source>The method spoton_crypt::cipherKeyLength() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1412"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1648"/>
        <source>A serious cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1278"/>
        <source>The method spoton_crypt::publicKeyDecrypt() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1313"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1379"/>
        <source>Stream error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1324"/>
        <source>The method spoton_crypt::keyedHash() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1334"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1400"/>
        <source>Invalid signature. Perhaps your contacts are not current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1957"/>
        <source>An error occurred while attempting to delete the specified participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="657"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="809"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1237"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1454"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="1513"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="2055"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="2074"/>
        <source>%1: New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="2130"/>
        <source>An error occurred while attempting to rename the specified participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="822"/>
        <source>Empty key(s). Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="67"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="72"/>
        <source>Copy My &amp;GPG Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="832"/>
        <source>Invalid key(s). The provided text must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="880"/>
        <source>Unable to retrieve your %1 public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="905"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1589"/>
        <source>The method spoton_crypt::publicKeyEncrypt() failed or an error occurred with the QDataStream object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1822"/>
        <source>Message was not signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1852"/>
        <source>Are you sure that you wish to remove the selected contact? The contact will also be removed from the GPG keyring.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="1856"/>
        <source>Are you sure that you wish to remove the selected contact?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rosetta_gpg_import</name>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="22"/>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="43"/>
        <source>Public Key(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="28"/>
        <source>gpg --armor --export you@you.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="50"/>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="222"/>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="225"/>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="244"/>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="381"/>
        <source>GPG Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="81"/>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="100"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="106"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="117"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="120"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="125"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rosetta-gpg-import.ui" line="130"/>
        <source>Remove GPG Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="60"/>
        <source>%1: Rosetta GPG Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="113"/>
        <source>E-Mail: %1&lt;br&gt;Key ID: %2&lt;br&gt;Name: %3&lt;br&gt;Fingerprint: %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="283"/>
        <source>GPGME error. Please verify that the provided keys are correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="314"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="317"/>
        <source>A cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="320"/>
        <source>Please provide non-empty keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="325"/>
        <source>Invalid crypt object. Critical error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="328"/>
        <source>Unable to access the database idiotes.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="339"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="353"/>
        <source>Are you sure that you wish to remove your GPG keys?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta-gpg-import.cc" line="356"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rss</name>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="223"/>
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="261"/>
        <source>%1: RSS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="236"/>
        <location filename="../GUI/spot-on-rss.cc" line="3032"/>
        <source>Copy Selected &amp;Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="233"/>
        <location filename="../GUI/spot-on-rss.cc" line="3030"/>
        <source>Copy All Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="240"/>
        <source>Delete &amp;All RSS Feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="243"/>
        <source>Delete &amp;Selected RSS Feed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="247"/>
        <location filename="../GUI/spot-on-rss.cc" line="3040"/>
        <source>&amp;Refresh Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="252"/>
        <source>&amp;Schedule Selected RSS Feed For Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1200"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1687"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1692"/>
        <source>Please provide atleast one RSS feed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1713"/>
        <source>Empty or invalid URL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1721"/>
        <source>URL scheme must be HTTP or HTTPS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1760"/>
        <source>Database or crypt-object error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1764"/>
        <source>Unable to access rss.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1777"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1993"/>
        <source>Are you sure that you wish to delete all of the RSS feeds?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="1997"/>
        <location filename="../GUI/spot-on-rss.cc" line="2041"/>
        <location filename="../GUI/spot-on-rss.cc" line="2497"/>
        <location filename="../GUI/spot-on-rss.cc" line="2820"/>
        <location filename="../GUI/spot-on-rss.cc" line="3295"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="2037"/>
        <source>Are you sure that you wish to delete the selected RSS feed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="2494"/>
        <source>Are you sure that you wish to purge obsolete links?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="2561"/>
        <source>Populating...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="2565"/>
        <source>%1: Populating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="2817"/>
        <source>Are you sure that you wish to remove all malformed links?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3035"/>
        <source>Delete &amp;All Feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3037"/>
        <source>Delete &amp;Selected Feed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3043"/>
        <source>&amp;Schedule Selected Feed For Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3107"/>
        <source>%1 RSS Feeds | %2 Failed Imports | %3 Hidden URLs | %4 Imported URLs | %5 Not Imported URLs | %6 Indexed URLs | %7 Not Indexed URLs | %8 Malformed | %9 Total URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3127"/>
        <source>0 RSS Feeds | 0 Failed Imports | 0 Hidden URLs | 0 Imported URLs | 0 Not Imported URLs | 0 Indexed URLs | 0 Not Indexed URLs | 0 Malformed | 0 Total URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rss.cc" line="3291"/>
        <source>Are you sure that you wish to remove %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="26"/>
        <source>&amp;Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="32"/>
        <source>Please note that the kernel will adhere to some of the following configuration options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="42"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="85"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="104"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="109"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="114"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="137"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="147"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="164"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="187"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="248"/>
        <source>Save Proxy Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="265"/>
        <source>Ignored by the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="281"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please verify that the URL database has been prepared. Please see the Search page of the main window. Ignored by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="308"/>
        <source>&amp;Download Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="321"/>
        <source> minute(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="284"/>
        <source>&amp;Periodic Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="347"/>
        <source>A large value may impede the import process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="377"/>
        <source>Context Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="380"/>
        <source>Context Menu Reflection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="437"/>
        <source>Feed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="442"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="450"/>
        <source>Add Feed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="462"/>
        <source>Atom 1.0 and RSS 2.0 feeds are supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="491"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="504"/>
        <source>&amp;Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="677"/>
        <location filename="../UI/spot-on-rss.ui" line="826"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="687"/>
        <source>Please press the Enter key after providing the search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="626"/>
        <source>Purge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="633"/>
        <source>links that are older than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="650"/>
        <source>&amp;day(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="562"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="567"/>
        <source>Imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="572"/>
        <source>Indexed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="577"/>
        <source>Malformed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="582"/>
        <source>Not Imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="587"/>
        <source>Not Indexed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="602"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="704"/>
        <source>&amp;Zoo Notices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="821"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="921"/>
        <source>&amp;Remove Malformed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="595"/>
        <location filename="../UI/spot-on-rss.ui" line="747"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="78"/>
        <source>Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="157"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="180"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="268"/>
        <source>&amp;Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="318"/>
        <source>Kernel monitors this setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="337"/>
        <source>&amp;Maximum Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="471"/>
        <source>&amp;Feed(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="481"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Multiple links may be specified. Please separate links via single spaces.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="484"/>
        <source>Feed(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="557"/>
        <source>Failed Imports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="690"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="727"/>
        <source>&amp;Record Notices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="770"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="776"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="780"/>
        <source>&amp;Timeline Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="790"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="804"/>
        <source>&amp;Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="818"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="829"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="837"/>
        <source>&amp;Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="848"/>
        <source>&amp;Publication Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="853"/>
        <source>Toggle &amp;Failed Imports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="858"/>
        <source>Toggle I&amp;mported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="863"/>
        <source>Toggle &amp;Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="868"/>
        <source>Toggle I&amp;ndexed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="873"/>
        <source>Toggle &amp;Shown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="878"/>
        <source>Toggle Mal&amp;formed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="883"/>
        <source>Toggle Not &amp;Indexed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="905"/>
        <source>&amp;Descriptions in Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="894"/>
        <source>&amp;Publication Dates in Timeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="552"/>
        <source>All (Not Hidden)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-rss.ui" line="916"/>
        <source>&amp;URL Links in Timeline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_smpwindow</name>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="26"/>
        <source>&amp;Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="50"/>
        <source>New Exchanges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="85"/>
        <source>Participant Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="95"/>
        <source>Public Key Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="90"/>
        <location filename="../UI/spot-on-smpwindow.ui" line="300"/>
        <source>Public Key Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="100"/>
        <location filename="../UI/spot-on-smpwindow.ui" line="310"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="134"/>
        <source>Data exchanged via Poptastic public keys shall be transferred over the Echo and the Poptastic mediums.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="146"/>
        <source>&amp;Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="125"/>
        <source>&amp;Clear Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="156"/>
        <source>Secret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="181"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="188"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Prepare an SMP object via the secret and the selected participant. The SMP object will be initialized to the zeroth state. If an SMP object exists for the selected participant, the object&apos;s secret will be updated.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="191"/>
        <source>&amp;Create SMP Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="212"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="219"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Prepare an SMP object via the secret and the selected participant. The SMP object will be initialized to the zeroth state. If an SMP object exists for the selected participant, the object&apos;s secret will be updated. If successful, launch SMP!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="222"/>
        <source>&amp;Execute SMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="242"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Generate a stream of bytes via the secret and the selected participant.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="245"/>
        <source>&amp;Generate Secret Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="257"/>
        <source>Verified Exchanges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="290"/>
        <source>Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="295"/>
        <source>Secret Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="305"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="333"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="349"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="376"/>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="382"/>
        <source>Please do not modify the Generator Hash Type, Generator Stream Size, and Iteration Count unless you have notified other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="397"/>
        <source>Generator &amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="417"/>
        <source>Generator &amp;Stream Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="440"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="450"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please do not modify the Iteration Count unless you have notified other participants.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="486"/>
        <source>Transfer &amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="506"/>
        <source>Transfer &amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="568"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="574"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="584"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="587"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-smpwindow.ui" line="592"/>
        <source>&amp;Purge SMP State Machines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="46"/>
        <source>%1: SMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="191"/>
        <source>%1: The smp object is zero in generateSecretData().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="203"/>
        <source>%1: The s_crypt object is zero in generateSecretData().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="217"/>
        <source>%1: An error occurred with spoton_crypt::publicKey() in generateSecretData().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="244"/>
        <source>%1: An error occurred with gcry_kdf_derive() in generateSecretData().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="369"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1070"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="403"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="541"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="828"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="961"/>
        <source>A total of %1 SMP objects are registered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="420"/>
        <source>%1: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="442"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw. Is a participant selected?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="452"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1251"/>
        <source>The interface&apos;s kernel socket is zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="458"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1256"/>
        <source>The interface is not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="465"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1262"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="474"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="783"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="893"/>
        <source>Please provide a non-empty secret.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="484"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="903"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="520"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="939"/>
        <source>A database error occurred while attempting to retrieve the specified participant&apos;s public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="556"/>
        <source>An error occurred with spoton_smp::step1().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="570"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="613"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="664"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1315"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1348"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1394"/>
        <source>QDataStream error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="583"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1324"/>
        <source>Unable to gather your public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="624"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1361"/>
        <source>An error occurred with spoton_crypt::publicKeyEncrypt().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="647"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1379"/>
        <source>An error occurred with spoton_crypt::digitalSignature().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="683"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1412"/>
        <source>An error occurred with spoton_crypt::encrypted().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="692"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1420"/>
        <source>An error occurred with spoton_crypt::keyedHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="705"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1432"/>
        <source>An error occurred while writing to the kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="726"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="881"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="991"/>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1129"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="982"/>
        <source>A total of 0 SMP objects are registered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1137"/>
        <source>Are you sure that you wish to remove the selected secret?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1140"/>
        <source>%1: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1186"/>
        <source>%1: Received a response from an unknown participant... Ignoring.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1199"/>
        <source>%1: Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1227"/>
        <source>%1: Received a response from %2. Currently at step %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1289"/>
        <source>%1: SMP verification with %2 experienced a protocol failure. Current step is %3. The specific state machine has been reset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1274"/>
        <source>%1: Verified secrets with %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="712"/>
        <source>%1: Contacting participant %2... Please wait for a response.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="773"/>
        <source>Please select a participant. Perhaps the participant has been removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1283"/>
        <source>%1: SMP verification with %2 has failed. The secrets are not congruent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1437"/>
        <source>%1: Submitted a response to %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-smpwindow.cc" line="1447"/>
        <source>%1: An error (%2) occurred while attempting to prepare the next SMP protocol step with %3.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_socket_options</name>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="49"/>
        <source>If data has not been exchanged for some period of time, send a keep-alive probe to the peer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="61"/>
        <source>SO_&amp;KEEPALIVE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="100"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;According to the FreeBSD setsockopt() manual page, SO_LINGER controls the action that is taken when unsent messages are queued on a socket and a close() is performed. If the socket promises reliable delivery of data and SO_LINGER is set, the system will block the process on the close() attempt until it is able to transmit the data or until it decides it is unable to deliver the information (a timeout period, termed the linger interval, is specified in seconds in the setsockopt() system call when SO_LINGER is requested). If SO_LINGER is disabled and a close() is issued, the system will process the close in a manner that allows the process to continue as quickly as possible. A value of negative one disables the option.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="112"/>
        <source>SO_&amp;LINGER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="122"/>
        <source> Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="160"/>
        <source>Set the receive buffer size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="172"/>
        <source>SO_&amp;RCVBUF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="182"/>
        <location filename="../UI/spot-on-socket-options.ui" line="242"/>
        <source> Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="220"/>
        <source>Set the send buffer size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="232"/>
        <source>SO_&amp;SNDBUF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="280"/>
        <source>Timestamp incoming and outgoing data packets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="292"/>
        <source>SO_&amp;TIMESTAMPING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="331"/>
        <source>Send data as soon as possible. If set, disable Nagle&apos;s algorithm.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="343"/>
        <source>TCP_&amp;NODELAY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="384"/>
        <source>Type of Service (&amp;IP_TOS)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="398"/>
        <source>0 Routine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="403"/>
        <source>32 Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="408"/>
        <source>64 Immediate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="413"/>
        <source>96 Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="418"/>
        <source>128 Flash Override</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="423"/>
        <source>160 CRITIC / ECP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="428"/>
        <source>192 Internetwork Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-socket-options.ui" line="433"/>
        <source>224 Network Control</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_statistics_window</name>
    <message>
        <location filename="../UI/spot-on-statisticswindow.ui" line="57"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statisticswindow.ui" line="65"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statisticswindow.ui" line="68"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_statusbar</name>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="38"/>
        <source>Lock the application. Similar to a screen saver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="41"/>
        <source>Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="48"/>
        <source>Pop Poptastic messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="122"/>
        <source>Buzz activity detected!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="135"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="151"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="232"/>
        <source>View Notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-statusbar.ui" line="216"/>
        <source>View Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_stylesheet</name>
    <message>
        <location filename="../UI/spot-on-stylesheet.ui" line="14"/>
        <source>Spot-On: Widget Style Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-stylesheet.ui" line="24"/>
        <source>Spot-On does not yet validate style sheets. Please be careful.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-stylesheet.ui" line="34"/>
        <source>Style Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-stylesheet.ui" line="43"/>
        <source>&amp;Preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_tabwidget</name>
    <message>
        <location filename="../GUI/spot-on-tabwidget.cc" line="74"/>
        <source>The database file email.db has reached its designated capacity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-tabwidget.cc" line="82"/>
        <source>The database file email.db has almost reached its designated capacity.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_unlock</name>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="38"/>
        <source>&amp;Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="48"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="71"/>
        <source>&amp;Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="78"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="85"/>
        <source>&amp;Answer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-unlock.ui" line="95"/>
        <source>Answer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_virtual_keyboard</name>
    <message>
        <location filename="../GUI/spot-on.h" line="102"/>
        <source>%1: Virtual Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_wizard</name>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="47"/>
        <source>Configuration Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Generate Local Keys&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="229"/>
        <source>Generate Public Key Pairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Public keys are excellent mechanisms for providing confidential communications such as e-mail and instant messaging. As such, RSA is a popular public-key cryptographic algorithm. It is widely used in today&apos;s communications.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="278"/>
        <source>Create RSA public-key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="293"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;You may select different algorithms after the initialization process as well as create new public-key pairs.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="345"/>
        <source>Kernel Launch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="14"/>
        <source>Spot-On: Configuration Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="64"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Welcome to Spot-On! To continue the initialization process, please press the Next button. You may also cancel the wizard and continue the initialization process via the advanced mode.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="149"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please provide a username and a passphrase. Authentication and encryption keys will be derived from the passphrase in order to secure local data.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="164"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On allows you to save Web content to local and remote databases. The content is secured via your URL credentials. A search engine is also included. You may prepare the URL credentials later.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="174"/>
        <source>Apply the derived credentials to URL containers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="384"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On includes a separate kernel program. The program is resposible for a multitude of tasks such as managing network communications.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="394"/>
        <source>Launch the Spot-On kernel upon completion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="441"/>
        <source>URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="478"/>
        <source>Automatically distribute collected URL data to known participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="488"/>
        <source>Enable URL distribution.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="500"/>
        <source>Create the SQLite urls.db database. Please note that this process may require a considerable amount of time to complete. If enabled, the kernel will not be activated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="510"/>
        <source>Prepare SQLite urls.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="556"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="563"/>
        <source>&amp;Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="570"/>
        <source>&amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/spot-on-wizard.ui" line="577"/>
        <source>&amp;Initialize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
