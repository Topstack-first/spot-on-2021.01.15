var searchData=
[
  ['cocoainitializer_0',['CocoaInitializer',['../classCocoaInitializer.html',1,'']]]
];
