var searchData=
[
  ['private_64',['Private',['../classCocoaInitializer_1_1Private.html',1,'CocoaInitializer']]]
];
