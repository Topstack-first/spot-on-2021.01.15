var searchData=
[
  ['private_2',['Private',['../classCocoaInitializer_1_1Private.html',1,'CocoaInitializer']]]
];
