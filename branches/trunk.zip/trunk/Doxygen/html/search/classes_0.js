var searchData=
[
  ['cocoainitializer_62',['CocoaInitializer',['../classCocoaInitializer.html',1,'']]]
];
