var searchData=
[
  ['libspoton_5fhandle_5fstruct_5ft_63',['libspoton_handle_struct_t',['../structlibspoton__handle__struct__t.html',1,'']]]
];
