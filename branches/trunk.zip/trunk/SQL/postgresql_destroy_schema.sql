DROP DATABASE IF EXISTS spot_on_user_db;
DROP USER IF EXISTS spot_on_administrator;
DROP USER IF EXISTS spot_on_user;
