CREATE USER spot_on_administrator ENCRYPTED PASSWORD 'spot_on_administrator';
CREATE USER spot_on_user ENCRYPTED PASSWORD 'spot_on_user';
