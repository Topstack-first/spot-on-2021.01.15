#!/bin/bash
# A test script.

cat Spot-On Spot-On Spot-On Spot-On Spot-On Spot-On \
Spot-On Spot-On Spot-On Spot-On Spot-On Spot-On Spot-On \
Spot-On Spot-On Spot-On Spot-On Spot-On Spot-On Spot-On - | nc 127.0.0.1 4710
